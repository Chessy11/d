<?php
/*
  Plugin Name: Solustrid Core
  Plugin URI: https://smartdata.tonytemplates.com/solustrid/
  Description: Helping for the SmartDataSoft theme.
  Version: 1.0
  Author: smartdatasoft
  Author URI: http://smartdatasoft.com/
  License: GPLv2 or later
  Text Domain: solustrid-core
  Domain Path: /languages/
 */

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function solustrid_core_load_textdomain() {
    load_plugin_textdomain('solustrid-core', false, dirname(__FILE__) . "/languages");
}

add_action('plugins_loaded', 'solustrid_core_load_textdomain');

function solustrid_core_admin_enqueue($hook) {
    if ($hook != 'edit.php' && $hook != 'post.php' && $hook != 'post-new.php' && $hook != 'widgets.php')
        return;
    wp_enqueue_script('custom-js', plugin_dir_url(__FILE__) . '/js/admin.js');
    if ($hook == "widgets.php") {
        wp_enqueue_media();
        wp_enqueue_script("solustrid-media-widget-js", plugin_dir_url(__FILE__) . '/widgets/js/media-gallery.js', array("jquery"), "1.0", 1);
    }
}

add_action('admin_enqueue_scripts', 'solustrid_core_admin_enqueue');

function solustrip_en_scripts() {
    wp_enqueue_script('fancybox', plugin_dir_url(__FILE__) . 'js/jquery.fancybox.js', array('jquery'), '', true);
}

add_action('wp_enqueue_scripts', 'solustrip_en_scripts');
/* ============================================================
 * Visual Composer shorrtcode config
 * ============================================================ */

define('PLUGIN_DIR', dirname(__FILE__) . '/');
require_once(PLUGIN_DIR . "breadcrumb-navxt/breadcrumb-navxt.php" );
require_once(PLUGIN_DIR . "elementor-addons/solustrid-elementor.php");

function __autoloadPostType($directory) {
    foreach (glob($directory . '*.php') as $filename) {
        if (file_exists($filename)) {
            include_once ($filename);
        }
    }
}

$classesPostTypeDir = PLUGIN_DIR . 'post-type/';
__autoloadPostType($classesPostTypeDir);


/*
 * widgets auto load
 */
$classesWidgetsDir = PLUGIN_DIR . 'widgets/';

function __autoloadWidgets($directory) {
    foreach (glob($directory . '*.php') as $filename) {
        if (file_exists($filename)) {
            include_once ($filename);
        }
    }
}

__autoloadWidgets($classesWidgetsDir);


/*
 * Meta Box Configuration Post Meta Option
 */
require_once(PLUGIN_DIR . "/lib/config-meta-box.php");
register_activation_hook(__FILE__, 'solustrid_activation_func');

function solustrid_activation_func() {
    file_put_contents(__DIR__ . '/my-loggg.txt', ob_get_contents());
}

function solustrid_add_excerpt_support_for_cpt() {
    add_post_type_support('solustrid_services', 'excerpt');
}

add_action('init', 'solustrid_add_excerpt_support_for_cpt');

function solustrid_add_excerpt_support_for_projects_cpt() {
    add_post_type_support('solustrid_projects', 'excerpt');
}

add_action('init', 'solustrid_add_excerpt_support_for_projects_cpt');


add_action('elementor/frontend/after_enqueue_styles', function () {
    wp_dequeue_style('font-awesome');
});

function solustrid_share_button_func() {
    ?>
    <span class="framwork-share-this">  
        <span class="icon fas fa-share-alt"></span>
        <span class="framwork-share-this-popup">
            <span>
                <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url(get_permalink()); ?>"><span class="fab fa-facebook-f"></span></a>
                <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://twitter.com/home?status=<?php echo urlencode(get_the_title()); ?>-<?php echo esc_url(get_permalink()); ?>"><span class="fab fa-twitter"></span></a>
                <a onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" href="https://plus.google.com/share?url=<?php echo esc_url(get_permalink()); ?>"><span class="fab fa-google-plus-g"></span></a>
            </span>
        </span>
    </span>
    <?php
}

add_action('solustrid_share_button', 'solustrid_share_button_func');
