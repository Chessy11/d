<?php
add_action('elementor/init', function() {
    if (!defined('ABSPATH'))
        exit;

    class Elementor_Control_Icon extends Elementor\Base_Control {

        public function get_type() {
            return 'icon';
        }

        public static function get_icons() {
            return [
                
                'icon-f-48' => 'icon-f-48',
                'icon-f-35' => 'icon-f-35',
                'icon-e-09' => 'icon-e-09',
                'icon-arrow_up' => 'icon-arrow_up',
                'icon-arrow_down' => 'icon-arrow_down',
                'icon-star' => 'icon-star',
                'icon-calendar' => 'icon-calendar',
                'icon-calendar-page' => 'icon-calendar-page',
                'icon-oil' => 'icon-oil',
                'icon-balance' => 'icon-balance',
                'icon-power' => 'icon-power',
                'icon-car-wheel' => 'icon-car-wheel',
                'icon-disc-brake' => 'icon-disc-brake',
                'icon-check' => 'icon-check',
                'icon-close-cross' => 'icon-close-cross',
                'icon-clock' => 'icon-clock',
                'icon-locate' => 'icon-locate',
                'icon-favorite' => 'icon-favorite',
                'icon-interface' => 'icon-interface',
                'icon-lines-menu' => 'icon-lines-menu',
                'icon-rocket' => 'icon-rocket',
                'icon-people-1' => 'icon-people-1',
                'icon-people' => 'icon-people',
                'icon-transport' => 'icon-transport',
                'icon-people-2' => 'icon-people-2',
                'icon-people-3' => 'icon-people-3',
                'icon-settings' => 'icon-settings',
                'icon-shape' => 'icon-shape',
                'icon-squares' => 'icon-squares',
                'icon-technology' => 'icon-technology',
                'icon-tool' => 'icon-tool',
                'icon-diploma' => 'icon-diploma',
                'icon-transport-1' => 'icon-transport-1',
                'icon-mark' => 'icon-mark',
                'icon-web-settings' => 'icon-web-settings',
                'icon-arrow-left' => 'icon-arrow-left',
                'icon-arrow-right' => 'icon-arrow-right',
                'icon-arrows-2' => 'icon-arrows-2',
                'icon-behance-logo' => 'icon-behance-logo',
                'icon-facebook-logo' => 'icon-facebook-logo',
                'icon-google-plus-logo' => 'icon-google-plus-logo',
                'icon-instagram-logo' => 'icon-instagram-logo',
                'icon-linkedin-logo' => 'icon-linkedin-logo',
                'icon-tumblr-logo' => 'icon-tumblr-logo',
                'icon-twitter-logo' => 'icon-twitter-logo',
            ];
        }

        protected function get_default_settings() {
            return [
                'icons' => self::get_icons(),
            ];
        }

        public function content_template() {
            ?>
            <div class="elementor-control-field">
                <label class="elementor-control-title">{{{ data.label }}}</label>
                <div class="elementor-control-input-wrapper">
                    <select class="elementor-control-icon" data-setting="{{ data.name }}" data-placeholder="<?php _e('Select Icon', 'elementor'); ?>">
                        <option value=""><?php _e('Select Icon', 'elementor'); ?></option>
                        <# _.each( data.icons, function( option_title, option_value ) { #>
                        <option value="{{ option_value }}">{{{ option_title }}}</option>
                        <# } ); #>
                    </select>
                </div>
            </div>
            <# if ( data.description ) { #>
            <div class="elementor-control-field-description">{{ data.description }}</div>
            <# } #>
            <?php
        }

    }

});

// ENQUEUE // Enqueueing Frontend stylesheet and scripts.
add_action('elementor/editor/after_enqueue_scripts', function() {
    wp_enqueue_style('icomoon', plugin_dir_url(__FILE__) . 'style.css');
});
// FRONTEND // After Elementor registers all styles.
add_action('elementor/frontend/after_register_styles', 'icons_enqueue_after_frontend');
function icons_enqueue_after_frontend() {
    wp_enqueue_style('icomoon', plugin_dir_url(__FILE__) . 'style.css', array(), '');
}

// EDITOR // Before the editor scripts enqueuing.
add_action('elementor/editor/before_enqueue_scripts', 'icons_enqueue_before_editor');
function icons_enqueue_before_editor() {
    wp_enqueue_style('icomoon', plugin_dir_url(__FILE__) . 'style.css', array(), '');
}

add_action('elementor/controls/controls_registered', function($el) {
    $el->register_control('icon', new Elementor_Control_Icon);
});
?>