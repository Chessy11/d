<?php

namespace solustrid;

class Element {

    public function __construct() {
        add_action('elementor/widgets/widgets_registered', array($this, 'widgets_registered'));
    }

    public function widgets_registered() {
        if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')) {
            require_once SOLUSTRID_INCLUDES . '/widgets/quote.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/brands.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/brands-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/innovation.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/services-icon.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/aboutindustry.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/aboutindustry2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/about.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/testimonials.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/testimonials-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/blogs-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/blogs.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/skill.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/skill-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/factsfunctions.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/offer.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/services.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/services-two.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/services-three.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/projects.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/projects-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/featured-projects.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/design.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/featurer-block.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/newsletter.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/newsletter-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/our-team.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/faqs.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/contact.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/contact-map.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/icon-block.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/counter.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/contact-home.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/services-page.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/page-about.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/mission.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/featurer-block-page.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/faqs-2.php';
            require_once SOLUSTRID_INCLUDES . '/widgets/approach.php';
        }
    }

}
