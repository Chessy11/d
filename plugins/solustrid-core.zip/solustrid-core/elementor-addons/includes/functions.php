<?php

if (!defined('ABSPATH'))
    exit;

add_action(
        'elementor/init', function() {
    \Elementor\Plugin::$instance->elements_manager->add_category(
            'solustrid', [
        'title' => __('Solustrid', 'solustrid-core'),
        'icon' => 'fa fa-plug',
            ], 1
    );
}
);

function get_all_post() {

    $options = array();
    $post_types = get_post_types();
    $post_type_not__in = array('attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset', 'elementor_library');

    foreach ($post_type_not__in as $post_type_not) {
        unset($post_types[$post_type_not]);
    }
    $post_type = array_values($post_types);
    $all_posts = get_posts(array(
        'post_type' => $post_type
            )
    );

    if (!empty($all_posts) && !is_wp_error($all_posts)) {
        foreach ($all_posts as $post) {
            $this->options[$post->ID] = strlen($post->post_title) > 20 ? substr($post->post_title, 0, 20) . '...' : $post->post_title;
        }
    }
    return $this->options;
}

function getContactFormId() {

    $contact_forms = array();
    $cf7 = get_posts('post_type="wpcf7_contact_form"&numberposts=-1');
    if ($cf7) {
        foreach ($cf7 as $cform) {
            $contact_forms[$cform->ID] = $cform->post_title;
        }
    } else {
        $contact_forms[__('No contact forms found', 'solustrid-core')] = 0;
    }
    return $contact_forms;
}

if (!function_exists('get_contact_form_7_posts')) :

    function get_contact_form_7_posts() {
        $args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1);
        $catlist = [];
        if ($categories = get_posts($args)) {
            foreach ($categories as $category) {
                (int) $catlist[$category->ID] = $category->post_title;
            }
        } else {
            (int) $catlist['0'] = esc_html__('No contect From 7 form found', 'solustrid-core');
        }
        return $catlist;
    }

endif;

if (!function_exists('get_all_pages')) :

    function get_all_pages() {
        $args = array('post_type' => 'page', 'posts_per_page' => -1);
        $catlist = [];
        if ($categories = get_posts($args)) {
            foreach ($categories as $category) {
                (int) $catlist[$category->ID] = $category->post_title;
            }
        } else {
            (int) $catlist['0'] = esc_html__('No Pages Found!', 'solustrid-core');
        }
        return $catlist;
    }

endif;

function solustrid_modify_controls($controls_registry) {
    // Get existing icons
    $icons = $controls_registry->get_control('icon')->get_settings('options');
    // Append new icons
    $new_icons = array_merge(
            array(
        'icon-secure_icon_02' => 'icon-secure_icon_02',
        'icon-secure_icon_03' => 'icon-secure_icon_03',
        'icon-secure_icon_04' => 'icon-secure_icon_04',
        'icon-secure_icon_05' => 'icon-secure_icon_05',
        'icon-secure_icon_07' => 'icon-secure_icon_07',
        'icon-secure_icon_08' => 'icon-secure_icon_08',
        'icon-n-07' => 'icon-n-07',
        'icon-n-02' => 'icon-n-02',
        'icon-n-05' => 'icon-n-05',
        'icon-n-06' => 'icon-n-06',
        'icon-h-58' => 'icon-h-58',
        'icon-h-59' => 'icon-h-59',
        'icon-h-60' => 'icon-h-60',
        'icon-h-61' => 'icon-h-61',
        'icon-h-62' => 'icon-h-62',
        'icon-e-01' => 'icon-e-01',
        'icon-e-02' => 'icon-e-02',
        'icon-e-03' => 'icon-e-03',
        'icon-e-04' => 'icon-e-04',
        'icon-e-05' => 'icon-e-05',
        'icon-e-06' => 'icon-e-06',
        'icon-e-07' => 'icon-e-07',
        'icon-e-08' => 'icon-e-08',
        'icon-e-09' => 'icon-e-09',
        'icon-e-10' => 'icon-e-10',
        'icon-e-11' => 'icon-e-11',
        'icon-e-12' => 'icon-e-12',
        'icon-e-13' => 'icon-e-13',
        'icon-e-14' => 'icon-e-14',
        'icon-e-15' => 'icon-e-15',
        'icon-e-16' => 'icon-e-16',
        'icon-e-17' => 'icon-e-17',
        'icon-e-18' => 'icon-e-18',
        'icon-e-19' => 'icon-e-19',
        'icon-e-20' => 'icon-e-20',
        'icon-e-21' => 'icon-e-21',
        'icon-e-22' => 'icon-e-22',
        'icon-e-23' => 'icon-e-23',
        'icon-e-24' => 'icon-e-24',
        'icon-e-25' => 'icon-e-25',
        'icon-e-26' => 'icon-e-26',
        'icon-e-27' => 'icon-e-27',
        'icon-e-28' => 'icon-e-28',
        'icon-e-29' => 'icon-e-29',
        'icon-e-30' => 'icon-e-30',
        'icon-e-31' => 'icon-e-31',
        'icon-e-32' => 'icon-e-32',
        'icon-e-33' => 'icon-e-33',
        'icon-e-34' => 'icon-e-34',
        'icon-e-35' => 'icon-e-35',
        'icon-e-36' => 'icon-e-36',
        'icon-e-37' => 'icon-e-37',
        'icon-e-38' => 'icon-e-38',
        'icon-e-39' => 'icon-e-39',
        'icon-e-40' => 'icon-e-40',
        'icon-e-41' => 'icon-e-41',
        'icon-e-42' => 'icon-e-42',
        'icon-e-43' => 'icon-e-43',
        'icon-e-44' => 'icon-e-44',
        'icon-e-45' => 'icon-e-45',
        'icon-e-46' => 'icon-e-46',
        'icon-e-47' => 'icon-e-47',
        'icon-e-48' => 'icon-e-48',
        'icon-e-49' => 'icon-e-49',
        'icon-e-50' => 'icon-e-50',
        'icon-e-51' => 'icon-e-51',
        'icon-e-52' => 'icon-e-52',
        'icon-e-53' => 'icon-e-53',
        'icon-e-54' => 'icon-e-54',
        'icon-e-55' => 'icon-e-55',
        'icon-e-56' => 'icon-e-56',
        'icon-e-57' => 'icon-e-57',
        'icon-e-58' => 'icon-e-58',
        'icon-e-59' => 'icon-e-59',
        'icon-e-60' => 'icon-e-60',
        'icon-e-61' => 'icon-e-61',
        'icon-e-62' => 'icon-e-62',
        'icon-e-63' => 'icon-e-63',
        'icon-e-64' => 'icon-e-64',
        'icon-e-65' => 'icon-e-65',
        'icon-e-66' => 'icon-e-66',
        'icon-e-67' => 'icon-e-67',
        'icon-e-68' => 'icon-e-68',
        'icon-e-69' => 'icon-e-69',
        'icon-e-70' => 'icon-e-70',
        'icon-e-71' => 'icon-e-71',
        'icon-e-72' => 'icon-e-72',
        'icon-e-73' => 'icon-e-73',
        'icon-e-74' => 'icon-e-74',
        'icon-e-75' => 'icon-e-75',
        'icon-e-76' => 'icon-e-76',
        'icon-e-77' => 'icon-e-77',
        'icon-e-78' => 'icon-e-78',
        'icon-e-79' => 'icon-e-79',
        'icon-e-80' => 'icon-e-80',
        'icon-e-81' => 'icon-e-81',
        'icon-e-82' => 'icon-e-82',
        'icon-e-83' => 'icon-e-83',
        'icon-e-84' => 'icon-e-84',
        'icon-e-85' => 'icon-e-85',
        'icon-e-86' => 'icon-e-86',
        'icon-e-87' => 'icon-e-87',
        'icon-e-88' => 'icon-e-88',
        'icon-e-89' => 'icon-e-89',
        'icon-e-90' => 'icon-e-90',
        'icon-e-91' => 'icon-e-91',
        'icon-e-92' => 'icon-e-92',
        'icon-e-93' => 'icon-e-93',
        'icon-e-94' => 'icon-e-94',
        'icon-e-95' => 'icon-e-95',
        'icon-e-96' => 'icon-e-96',
        'icon-f-01' => 'icon-f-01',
        'icon-f-02' => 'icon-f-02',
        'icon-f-03' => 'icon-f-03',
        'icon-f-04' => 'icon-f-04',
        'icon-f-05' => 'icon-f-05',
        'icon-f-06' => 'icon-f-06',
        'icon-f-07' => 'icon-f-07',
        'icon-f-08' => 'icon-f-08',
        'icon-f-09' => 'icon-f-09',
        'icon-f-10' => 'icon-f-10',
        'icon-f-11' => 'icon-f-11',
        'icon-f-12' => 'icon-f-12',
        'icon-f-13' => 'icon-f-13',
        'icon-f-14' => 'icon-f-14',
        'icon-f-15' => 'icon-f-15',
        'icon-f-16' => 'icon-f-16',
        'icon-f-17' => 'icon-f-17',
        'icon-f-18' => 'icon-f-18',
        'icon-f-19' => 'icon-f-19',
        'icon-f-20' => 'icon-f-20',
        'icon-f-21' => 'icon-f-21',
        'icon-f-22' => 'icon-f-22',
        'icon-f-23' => 'icon-f-23',
        'icon-f-24' => 'icon-f-24',
        'icon-f-25' => 'icon-f-25',
        'icon-f-26' => 'icon-f-26',
        'icon-f-27' => 'icon-f-27',
        'icon-f-28' => 'icon-f-28',
        'icon-f-29' => 'icon-f-29',
        'icon-f-30' => 'icon-f-30',
        'icon-f-31' => 'icon-f-31',
        'icon-f-32' => 'icon-f-32',
        'icon-f-33' => 'icon-f-33',
        'icon-f-34' => 'icon-f-34',
        'icon-f-35' => 'icon-f-35',
        'icon-f-36' => 'icon-f-36',
        'icon-f-37' => 'icon-f-37',
        'icon-f-38' => 'icon-f-38',
        'icon-f-39' => 'icon-f-39',
        'icon-f-40' => 'icon-f-40',
        'icon-f-41' => 'icon-f-41',
        'icon-f-42' => 'icon-f-42',
        'icon-f-43' => 'icon-f-43',
        'icon-f-44' => 'icon-f-44',
        'icon-f-45' => 'icon-f-45',
        'icon-f-46' => 'icon-f-46',
        'icon-f-47' => 'icon-f-47',
        'icon-f-48' => 'icon-f-48',
        'icon-f-49' => 'icon-f-49',
        'icon-f-50' => 'icon-f-50',
        'icon-f-51' => 'icon-f-51',
        'icon-f-51' => 'icon-f-51',
        'icon-f-52' => 'icon-f-52',
        'icon-f-53' => 'icon-f-53',
        'icon-f-54' => 'icon-f-54',
        'icon-f-55' => 'icon-f-55',
        'icon-f-56' => 'icon-f-56',
        'icon-f-57' => 'icon-f-57',
        'icon-f-58' => 'icon-f-58',
        'icon-f-59' => 'icon-f-59',
        'icon-f-60' => 'icon-f-60',
        'icon-f-61' => 'icon-f-61',
        'icon-f-62' => 'icon-f-62',
        'icon-f-63' => 'icon-f-63',
        'icon-f-64' => 'icon-f-64',
        'icon-f-65' => 'icon-f-65',
        'icon-f-66' => 'icon-f-66',
        'icon-f-67' => 'icon-f-67',
        'icon-f-68' => 'icon-f-68',
        'icon-f-69' => 'icon-f-69',
        'icon-f-70' => 'icon-f-70',
        'icon-f-71' => 'icon-f-71',
        'icon-f-72' => 'icon-f-72',
        'icon-f-73' => 'icon-f-73',
        'icon-f-74' => 'icon-f-74',
        'icon-f-75' => 'icon-f-75',
        'icon-f-76' => 'icon-f-76',
        'icon-f-77' => 'icon-f-77',
        'icon-f-78' => 'icon-f-78',
        'icon-f-79' => 'icon-f-79',
        'icon-f-80' => 'icon-f-80',
        'icon-f-81' => 'icon-f-81',
        'icon-f-82' => 'icon-f-82',
        'icon-f-83' => 'icon-f-83',
        'icon-f-84' => 'icon-f-84',
        'icon-f-85' => 'icon-f-85',
        'icon-f-86' => 'icon-f-86',
        'icon-f-87' => 'icon-f-87',
        'icon-f-88' => 'icon-f-88',
        'icon-f-89' => 'icon-f-89',
        'icon-f-90' => 'icon-f-90',
        'icon-f-91' => 'icon-f-91',
        'icon-f-92' => 'icon-f-92',
        'icon-f-93' => 'icon-f-93',
        'icon-f-94' => 'icon-f-94',
        'icon-f-95' => 'icon-f-95',
        'icon-f-96' => 'icon-f-96',
        'icon-g-01' => 'icon-g-01',
        'icon-g-02' => 'icon-g-02',
        'icon-g-03' => 'icon-g-03',
        'icon-g-04' => 'icon-g-04',
        'icon-g-05' => 'icon-g-05',
        'icon-g-06' => 'icon-g-06',
        'icon-g-07' => 'icon-g-07',
        'icon-g-08' => 'icon-g-08',
        'icon-g-09' => 'icon-g-09',
        'icon-g-10' => 'icon-g-10',
        'icon-g-11' => 'icon-g-11',
        'icon-g-12' => 'icon-g-12',
        'icon-g-13' => 'icon-g-13',
        'icon-g-14' => 'icon-g-14',
        'icon-g-15' => 'icon-g-15',
        'icon-g-16' => 'icon-g-16',
        'icon-g-17' => 'icon-g-17',
        'icon-g-18' => 'icon-g-18',
        'icon-g-19' => 'icon-g-19',
        'icon-g-20' => 'icon-g-20',
        'icon-g-21' => 'icon-g-21',
        'icon-g-22' => 'icon-g-22',
        'icon-g-23' => 'icon-g-23',
        'icon-g-24' => 'icon-g-24',
        'icon-g-25' => 'icon-g-25',
        'icon-g-26' => 'icon-g-26',
        'icon-g-27' => 'icon-g-27',
        'icon-g-28' => 'icon-g-28',
        'icon-g-29' => 'icon-g-29',
        'icon-g-30' => 'icon-g-30',
        'icon-g-31' => 'icon-g-31',
        'icon-g-32' => 'icon-g-32',
        'icon-g-33' => 'icon-g-33',
        'icon-g-34' => 'icon-g-34',
        'icon-g-35' => 'icon-g-35',
        'icon-g-36' => 'icon-g-36',
        'icon-g-37' => 'icon-g-37',
        'icon-g-38' => 'icon-g-38',
        'icon-g-39' => 'icon-g-39',
        'icon-g-40' => 'icon-g-40',
        'icon-g-41' => 'icon-g-41',
        'icon-g-42' => 'icon-g-42',
        'icon-g-43' => 'icon-g-43',
        'icon-g-44' => 'icon-g-44',
        'icon-g-45' => 'icon-g-45',
        'icon-g-46' => 'icon-g-46',
        'icon-g-47' => 'icon-g-47',
        'icon-g-48' => 'icon-g-48',
        'icon-g-49' => 'icon-g-49',
        'icon-g-50' => 'icon-g-50',
        'icon-g-51' => 'icon-g-51',
        'icon-g-52' => 'icon-g-52',
        'icon-g-53' => 'icon-g-53',
        'icon-g-54' => 'icon-g-54',
        'icon-g-55' => 'icon-g-55',
        'icon-g-56' => 'icon-g-56',
        'icon-g-57' => 'icon-g-57',
        'icon-g-58' => 'icon-g-58',
        'icon-g-59' => 'icon-g-59',
        'icon-g-60' => 'icon-g-60',
        'icon-g-61' => 'icon-g-61',
        'icon-g-62' => 'icon-g-62',
        'icon-g-63' => 'icon-g-63',
        'icon-g-64' => 'icon-g-64',
        'icon-g-65' => 'icon-g-65',
        'icon-g-66' => 'icon-g-66',
        'icon-g-67' => 'icon-g-67',
        'icon-g-68' => 'icon-g-68',
        'icon-g-69' => 'icon-g-69',
        'icon-g-70' => 'icon-g-70',
        'icon-g-71' => 'icon-g-71',
        'icon-g-72' => 'icon-g-72',
        'icon-g-73' => 'icon-g-73',
        'icon-g-74' => 'icon-g-74',
        'icon-g-75' => 'icon-g-75',
        'icon-g-76' => 'icon-g-76',
        'icon-g-77' => 'icon-g-77',
        'icon-g-78' => 'icon-g-78',
        'icon-g-79' => 'icon-g-79',
        'icon-g-80' => 'icon-g-80',
        'icon-g-81' => 'icon-g-81',
        'icon-g-82' => 'icon-g-82',
        'icon-g-83' => 'icon-g-83',
        'icon-g-84' => 'icon-g-84',
        'icon-g-85' => 'icon-g-85',
        'icon-g-86' => 'icon-g-86',
        'icon-g-87' => 'icon-g-87',
        'icon-g-88' => 'icon-g-88',
        'icon-g-89' => 'icon-g-89',
        'icon-g-90' => 'icon-g-90',
        'icon-g-91' => 'icon-g-91',
        'icon-g-92' => 'icon-g-92',
        'icon-g-93' => 'icon-g-93',
        'icon-g-94' => 'icon-g-94',
        'icon-g-95' => 'icon-g-95',
        'icon-g-96' => 'icon-g-96',
        'icon-h-01' => 'icon-h-01',
        'icon-h-02' => 'icon-h-02',
        'icon-h-03' => 'icon-h-03',
        'icon-h-04' => 'icon-h-04',
        'icon-h-05' => 'icon-h-05',
        'icon-h-06' => 'icon-h-06',
        'icon-h-07' => 'icon-h-07',
        'icon-h-08' => 'icon-h-08',
        'icon-h-09' => 'icon-h-09',
        'icon-h-10' => 'icon-h-10',
        'icon-h-11' => 'icon-h-11',
        'icon-h-12' => 'icon-h-12',
        'icon-h-13' => 'icon-h-13',
        'icon-h-14' => 'icon-h-14',
        'icon-h-15' => 'icon-h-15',
        'icon-h-16' => 'icon-h-16',
        'icon-h-17' => 'icon-h-17',
        'icon-h-18' => 'icon-h-18',
        'icon-h-19' => 'icon-h-19',
        'icon-h-20' => 'icon-h-20',
        'icon-h-21' => 'icon-h-21',
        'icon-h-22' => 'icon-h-22',
        'icon-h-23' => 'icon-h-23',
        'icon-h-24' => 'icon-h-24',
        'icon-h-25' => 'icon-h-25',
        'icon-h-26' => 'icon-h-26',
        'icon-h-27' => 'icon-h-27',
        'icon-h-28' => 'icon-h-28',
        'icon-h-29' => 'icon-h-29',
        'icon-h-30' => 'icon-h-30',
        'icon-h-31' => 'icon-h-31',
        'icon-h-32' => 'icon-h-32',
        'icon-h-33' => 'icon-h-33',
        'icon-h-34' => 'icon-h-34',
        'icon-h-35' => 'icon-h-35',
        'icon-h-36' => 'icon-h-36',
        'icon-h-37' => 'icon-h-37',
        'icon-h-38' => 'icon-h-38',
        'icon-h-39' => 'icon-h-39',
        'icon-h-40' => 'icon-h-40',
        'icon-h-41' => 'icon-h-41',
        'icon-h-42' => 'icon-h-42',
        'icon-h-43' => 'icon-h-43',
        'icon-h-44' => 'icon-h-44',
        'icon-h-45' => 'icon-h-45',
        'icon-h-46' => 'icon-h-46',
        'icon-h-47' => 'icon-h-47',
        'icon-h-48' => 'icon-h-48',
        'icon-h-49' => 'icon-h-49',
        'icon-h-50' => 'icon-h-50',
        'icon-h-51' => 'icon-h-51',
        'icon-h-52' => 'icon-h-52',
        'icon-h-53' => 'icon-h-53',
        'icon-h-54' => 'icon-h-54',
        'icon-h-55' => 'icon-h-55',
        'icon-h-56' => 'icon-h-56',
        'icon-h-57' => 'icon-h-57'
            ), $icons
    );
    // Then we set a new list of icons as the options of the icon control
    $controls_registry->get_control('icon')->set_settings('options', $new_icons);
}

add_action('elementor/controls/controls_registered', 'solustrid_modify_controls', 10, 1);
