<?php

namespace solustrid;

class Scripts {

    public function __construct() {
        add_action('elementor/frontend/after_register_scripts', array($this, 'required_script'));
    }

    public function required_script() {
        wp_enqueue_script('solustrid-elemt', SOLUSTRID_ASSETS . '/js/elementor-custom.js', array('jquery'), '', true);
    }
}
