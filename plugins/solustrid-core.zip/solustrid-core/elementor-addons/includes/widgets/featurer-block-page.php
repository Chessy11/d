<?php

use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class PageFeaturedBlock extends \Elementor\Widget_Base {

    public function get_name() {
        return 'pagefeatureblock';
    }

    public function get_title() {
        return esc_html__('Featured Block Page', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_section', [
            'label' => __('Featured Content', 'solustrid-core'),
                ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $repeater->add_control(
                'icon', [
            'label' => __('Icon', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::ICON,
            'default' => 'icon flaticon-market',
            'include' => [
                'icon flaticon-engineer-2',
                'icon flaticon-earth-globe',
                'icon flaticon-flask'
            ],
                ]
        );

        $repeater->add_control(
                'action_link', [
            'label' => __('URL', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'solustrid-core'),
            'show_external' => true,
            'default' => [
                'url' => '#',
                'is_external' => true,
                'nofollow' => true,
            ],
                ]
        );

        $repeater->add_control(
                'url_text', [
            'label' => __('URL Text', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('Experts Engineers Support', 'solustrid-core'),
            'placeholder' => __('Type your text here', 'solustrid-core'),
                ]
        );

        $repeater->add_control(
                'content', [
            'label' => __('Content', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('Aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit voluptate sed velit sunt in culpa qui officia deseru mollit anim ipsum id est laborum.', 'solustrid-core'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'items', [
            'label' => __('Repeater List', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'list_title' => __('Title #1', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ],
                [
                    'list_title' => __('Title #2', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ],
                [
                    'list_title' => __('Title #3', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ]
            ],
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <!-- Featured Services -->
        <section class="featured-services">
            <div class="row no-gutters">
                <?php
                foreach ($settings['items'] as $item) {
                    $bg_image = isset($item['image']['url']) ? $item['image']['url'] : '#';
                    $url = '#';
                    $target = '';
                    if (!empty($item['action_link'])) {
                        $link = $item['action_link'];
                        $url = $link['url'];
                        $target = $link['is_external'] ? 'target="_blank"' : '';
                    }
                    ?>
                    <!-- Feature Block Five -->
                    <div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0ms">
                        <div class="inner-box" style="background-image: url(<?php echo esc_url($bg_image); ?>);">
                            <div class="content">
                                <div class="icon-box"><span class="<?php echo esc_attr($item['icon']); ?>"></span></div>
                                <h4><a href="<?php echo esc_url($url); ?>"><?php echo $item['url_text']; ?></a></h4>
                                <div class="text"><?php echo $item['content']; ?></div>
                                <div class="link-box"><a href="<?php echo esc_url($url); ?>"><?php echo esc_html__('Read More', 'solustrid-core') ?><i class="fa fa-angle-right"></i></a></div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </section>
        <!--End Featured Services -->
        <?php
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new PageFeaturedBlock());
