<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Blogs2 extends Widget_Base {

    public function get_name() {
        return 'blogstwo';
    }

    public function get_title() {
        return esc_html__('Blog Two', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    private function get_blog_categories() {
        $options = array();
        $taxonomy = 'category';
        if (!empty($taxonomy)) {
            $terms = get_terms(
                    array(
                        'parent' => 0,
                        'taxonomy' => $taxonomy,
                        'hide_empty' => false,
                    )
            );
            if (!empty($terms)) {
                foreach ($terms as $term) {
                    if (isset($term)) {
                        $options[''] = 'Select';
                        if (isset($term->slug) && isset($term->name)) {
                            $options[$term->slug] = $term->name;
                        }
                    }
                }
            }
        }
        return $options;
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Blogs', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('News and insights', 'solustrid-core')
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit voluptate velit sunt in culpa qui officia deseru mollit anim ipsum id est laborum.'
                ]
        );

        $this->add_control(
                'category_id', [
            'type' => \Elementor\Controls_Manager::SELECT,
            'label' => esc_html__('Category', 'solustrid-core'),
            'options' => $this->get_blog_categories()
                ]
        );

        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__(3, 'solustrid-core')
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => array('post'),
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'category_name' => $settings['category_id'],
            'orderby' => $order_by,
            'order' => $order,
        );
        $query = new WP_Query($args);
        ?>
        <!-- News Section Two -->
        <section class="news-section-two">
            <div class="auto-container">
                <!-- Sec Title -->
                <div class="sec-title light">
                    <div class="row clearfix">
                        <div class="pull-left col-xl-4 col-lg-5 col-md-12 col-sm-12">
                            <div class="title"> <?php
                                echo wp_kses_post($settings['title_1']);
                                ?></div>
                            <h2> <?php
                                echo wp_kses_post($settings['title_2']);
                                ?></h2>
                        </div>
                        <div class="pull-right col-xl-8 col-lg-7 col-md-12 col-sm-12">
                            <div class="text">
                                <?php
                                echo wp_kses_post($settings['content']);
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="news-carousel owl-carousel owl-theme">
                <?php
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                        $query->the_post();
                        ?>
                        <!-- News Block Four -->
                        <div class="news-block-four">
                            <div class="inner-box">
                                <div class="image">
                                    <?php
                                    $solustrid_pmeta_image = get_post_meta(get_the_ID(), 'framework-meta-image', TRUE);
                                    $solustrid_image_src = wp_get_attachment_image_src($solustrid_pmeta_image, 'full');
                                    ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo esc_url($solustrid_image_src[0]); ?>" alt="<?php echo esc_attr('Alt'); ?>" />
                                    </a>
                                </div>
                                <div class="lower-content">
                                    <?php
                                    the_title('<h3><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>');
                                    ?>
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="read-more"><span class="arrow fas fa-angle-right"></span></a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                }
                ?>
            </div>
        </section>
        <!-- End News Section Two -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Blogs2());
