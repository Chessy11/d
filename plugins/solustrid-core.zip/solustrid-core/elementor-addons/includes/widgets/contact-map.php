<?php

use Elementor\Utils;
use Elementor\Plugin;

class contactMap extends \Elementor\Widget_Base {

    public function get_name() {
        return 'Map';
    }

    public function get_title() {
        return esc_html__('Map', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_section', [
            'label' => __('Map Content', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'latitudes', [
            'label' => __('Latitudes', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('-37.817085', 'solustrid-core'),
            'dynamic' => ['active' => true]
                ]
        );
        $this->add_control(
                'longitudes', [
            'label' => __('Longitudes', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('144.955631', 'solustrid-core'),
            'dynamic' => ['active' => true]
                ]
        );
        $this->add_control(
                'title', [
            'label' => __('Title', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('Solustrid', 'solustrid-core'),
            'dynamic' => ['active' => true]
                ]
        );

        $this->add_control(
                'content', [
            'label' => __('Content', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 0,
            'default' => "Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>"
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $lat = $settings['latitudes'];
        $long = $settings['longitudes'];
        $title = $settings['title'];
        $content = $settings['content'];
        ?>
        <!-- Contact Map Section -->
        <section class="contact-map-section">
            <div class="outer-container">
                <div class="map-outer">
                    <div class="map-canvas"
                         data-zoom="12"
                         data-lat="<?php echo esc_attr($lat) ?>"
                         data-lng="<?php echo esc_attr($long) ?>"
                         data-type="roadmap"
                         data-hue="#ffc400"
                         data-title="<?php echo esc_attr($title) ?>"
                         data-icon-path="<?php echo SOLUSTRID_IMG_URL; ?>/icons/map-marker.png"
                         data-content="<?php echo wp_kses_post($content); ?>">
                    </div>
                </div>
            </div>
        </section>
        <!-- End Map Section -->
        <?php
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new contactMap());
