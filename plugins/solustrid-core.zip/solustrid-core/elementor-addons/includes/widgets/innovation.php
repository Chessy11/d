<?php

namespace wokiee\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Innovation extends Widget_Base {

    public function get_name() {
        return 'innovation';
    }

    public function get_title() {
        return esc_html__('Innovation', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'innovation_section', [
            'label' => esc_html__('Innovation', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Transforming <br> With Innovations', 'solustrid-core')
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Description', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__('Dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.', 'solustrid-core')
                ]
        );

        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Counter 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'counter_text',
                    'label' => esc_html__('Counter Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '25'
                ],
                [
                    'name' => 'unit_text',
                    'label' => esc_html__('Counter Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                ],
                [
                    'name' => 'counter_title',
                    'label' => esc_html__('Counter Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Industries Served'
                ],
                [
                    'name' => 'data_speed',
                    'label' => esc_html__('Data Speed', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '2000'
                ],
            ],
            'title_field' => '{{tab_title}}',
                ]
        );


        $this->add_control(
                'image', [
            'label' => __('Image 1', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'image_1', [
            'label' => __('Image 2', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }


        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
            $image_url_1 = Group_Control_Image_Size::get_attachment_image_src($settings['image_1']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }

            if (!empty($settings['image_1']['id'])) {

                $image_src_1 = wp_get_attachment_image_src($settings['image_1']['id'], $attachment_size);
                $image_url_1 = $image_src_1[0];
            } else {
                $image_url_1 = $settings['image_1']['url'];
            }
        }
        ?>
        <!-- Innovation Section -->
        <section class="innovation-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <!-- Sec Title -->
                            <div class="sec-title wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="title"><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?>
                                </h2>
                            </div>
                            <?php
                            echo wp_kses_post($settings['content']);
                            ?>
                            <div class="counter-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="fact-counter">
                                    <div class="clearfix">
                                        <!--Column-->
                                        <?php foreach ($settings['countertex_tabs_tab'] as $tab) { ?>
                                            <div class="column counter-column col-lg-4 col-md-4 col-sm-12">
                                                <div class="inner">
                                                    <div class="count-outer count-box">
                                                        <span class="count-text" data-speed="<?php
                                                        echo esc_attr($tab['data_speed']);
                                                        ?>" data-stop="<?php
                                                              echo esc_attr($tab['counter_text']);
                                                              ?>">0</span><?php
                                                              if ($tab['unit_text']) {
                                                                  echo wp_kses_post($tab['unit_text']);
                                                              }
                                                              ?>
                                                        <h4 class="counter-title"><?php
                                                            echo wp_kses_post($tab['counter_title']);
                                                            ?>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Imaages Column -->
                    <div class="images-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="image wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                            </div>
                            <div class="image wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <img src="<?php echo esc_url($image_url_1); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Innovation Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Innovation());
