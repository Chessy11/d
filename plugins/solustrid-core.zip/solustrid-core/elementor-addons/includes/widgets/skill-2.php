<?php
namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Skill2 extends Widget_Base {

    public function get_name() {
        return 'skill2';
    }

    public function get_title() {
        return esc_html__('Skill 2', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'skill_left_section', [
            'label' => esc_html__('Skill Left Section', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We are Solustrid'
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'History of Innovative Engineering'
                ]
        );

        $this->add_control(
                'left_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'date_title',
                    'label' => esc_html__('Date', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '<span>JAN</span> 2019'
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Searching for Minerals Fields'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Aliquip ex ea commodo consequat duis aute irure dolor in velit sunt in culpa qui officia deseru mollit.'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'skill_right_section', [
            'label' => esc_html__('Skill Right Section', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We produce positive results from ever-growing <span>Industrial & manufacturing</span> estates.'
                ]
        );

        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Skill Item 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Skill Item 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Skill Item 3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'skill_title',
                    'label' => esc_html__('Skill Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Latest Equipemnts Used'
                ],
                [
                    'name' => 'skill_percentage',
                    'label' => esc_html__('Skill Percentage', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '95'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );


        $this->add_control(
                'action_link', [
            'label' => __('Button Link', 'solustrid-core'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => '#',
                'is_external' => '',
            ],
            'show_external' => true,
                ]
        );

        $this->add_control(
                'button_text', [
            'label' => esc_html__('Button Text', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'watch the intro video'
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }
        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }
        }
        ?>

        <!-- Fluid Section Two -->
        <section class="fluid-section-two">
            <div class="image-layer" style="background-image:url(<?php echo esc_url($image_url); ?>)"></div>
            <div class="outer-container clearfix">
                <!--Left Column-->
                <div class="left-column">
                    <div class="inner-column">
                        <!-- Sec Title -->
                        <div class="sec-title light">
                            <div class="title">
                                <?php
                                echo wp_kses_post($settings['title_1']);
                                ?>
                            </div>
                            <h2> 
                                <?php
                                echo wp_kses_post($settings['title_2']);
                                ?>
                            </h2>
                        </div>
                        <div class="history-outer">
                            <!-- History Block -->
                            <?php foreach ($settings['left_tabs_tab'] as $tab) { ?>
                                <div class="history-block">
                                    <div class="inner-block">
                                        <div class="date">
                                            <?php
                                            echo wp_kses_post($tab['date_title']);
                                            ?>
                                        </div>
                                        <h3>
                                            <a href="#">  
                                                <?php
                                                echo wp_kses_post($tab['title']);
                                                ?>
                                            </a>
                                        </h3>
                                        <div class="history-text">
                                            <?php
                                            echo wp_kses_post($tab['content']);
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <a class="read-more" href="#"><?php echo esc_html('read full history', 'solustrid-core') ?><span class="icon fas fa-angle-right"></span></a>
                    </div>
                </div>
                <!-- Right Column -->
                <div class="right-column">
                    <div class="inner-column">
                        <div class="video-link-box">
                            <a href="<?php echo esc_url($url); ?>" class="lightbox-image play-box">
                                <span class="icon-outer"><span class="icon flaticon-play-button"><i class="ripple"></i></span></span></a>
                            <div class="video-title"><?php echo esc_html($settings['button_text']); ?>
                            </div>
                        </div>
                        <h2>
                            <?php
                            echo wp_kses_post($settings['title']);
                            ?>
                        </h2>
                        <!--Skills-->
                        <div class="skills style-two">
                            <?php foreach ($settings['countertex_tabs_tab'] as $tab) { ?>
                                <!--Skill Item-->
                                <div class="skill-item">
                                    <div class="skill-header clearfix">
                                        <div class="skill-title">
                                            <?php
                                            echo wp_kses_post($tab['skill_title']);
                                            ?>
                                        </div>
                                        <div class="skill-percentage">
                                            <div class="count-box">
                                                <span class="count-text" data-speed="2000" data-stop="<?php echo esc_attr($tab['skill_percentage']); ?>">0</span>%</div>
                                        </div>
                                    </div>
                                    <div class="skill-bar">
                                        <div class="bar-inner"><div class="bar progress-line" data-width="<?php echo esc_attr($tab['skill_percentage']); ?>"></div></div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Skill2());
