<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class ServicesTwo extends Widget_Base {

    public function get_name() {
        return 'custom_services2';
    }

    public function get_title() {
        return esc_html__('Services Two', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Services', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('What We Do', 'solustrid-core')
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Heading Content', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => '<p>Incididunt ut labore et dolore magna aliquat enim trud exercitation ullamco laboris nisi ut aliquip ex aute irure dolor in reprehenderit velit culpa quis labore dolore magna aliqua.</p>
                         <p>Ain voluptate velit. Sunt in culpa qui officia deseru mollit anim id est laborum unde omnis.</p>'
                ]
        );


        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 5
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'delay_time', [
            'label' => esc_html__('Delay Time', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '300'
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $delay_time = $settings['delay_time'];
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => 'solustrid_services',
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        ?>

        <!-- Services Section Three -->
        <section class="services-section-three">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Services Block Three -->
                    <div class="services-block-three col-xl-4 col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <!-- Sec Title -->
                            <div class="sec-title">
                                <div class="title">
                                    <?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?>
                                </div>
                                <h2>
                                    <?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?>
                                </h2>
                            </div>
                            <div class="text">
                                <?php
                                echo wp_kses_post($settings['content']);
                                ?>
                            </div>

                            <?php
                            $slug_postype_service = 'services';
                            $solustrid_options = solustrid_options();
                            if (function_exists('solustrid_options')) {
                                $solustrid_options = solustrid_options();
                                if (isset($solustrid_options['solustrid_slug_postype_program']) && !empty($solustrid_options['solustrid_slug_postype_program'])) {
                                    $slug_postype_service = $solustrid_options['solustrid_slug_postype_program'];
                                }
                            }
                            ?>
                            <div class="link-box"><a href="<?php echo site_url() . '/' . $slug_postype_service; ?>" class="theme-btn btn-style-seven"><?php echo esc_html__('All Services', 'solustrid-core') ?></a></div>
                        </div>
                    </div>
                    <?php
                    $i = 1;
                    if ($query->have_posts()) {
                        while ($query->have_posts()) {
                            $dataDelay = ((int) $delay_time ) * $i;
                            $query->the_post();
                            $solustrid_pmeta_image = get_post_meta(get_the_ID(), 'framework-home-sect-image', TRUE);
                            $solustrid_image_src = wp_get_attachment_image_src($solustrid_pmeta_image, 'full');
                            ?>
                            <!-- Services Block Three -->
                            <div class="services-block-three col-xl-4 col-lg-6 col-md-6 col-sm-12">
                                <div class="inner-box wow fadeInUp" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="1500ms">
                                    <div class="image">
                                        <a href="<?php echo esc_url(the_permalink()); ?>">
                                            <?php if (isset($solustrid_image_src[0]) && !empty($solustrid_image_src[0])) { ?>
                                                <img src="<?php echo esc_url($solustrid_image_src[0]); ?>" alt="<?php echo esc_attr('Alt'); ?>"/>
                                                <?php
                                            } else {
                                                the_post_thumbnail();
                                            }
                                            ?>
                                        </a>
                                    </div>
                                    <div class="lower-content">
                                        <h3><a href="<?php echo esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h3>
                                        <div class="text"><?php the_excerpt(); ?></div>
                                        <a href="<?php echo esc_url(the_permalink()); ?>" class="read-more"><?php echo esc_html__('Read More', 'solustrid-core'); ?> <span class="fas fa-angle-right"></span></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $i++;
                            if ($i == 3) {
                                $i = 0;
                            }
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </div>
            </div>
        </section>
        <!-- End Services Section Three -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new ServicesTwo());
