<?php
namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class TestimonialsTwo extends Widget_Base {

    public function get_name() {
        return 'testimonials2';
    }

    public function get_title() {
        return esc_html__('Testimonials Two', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Client’s Reviews', 'solustrid-core')
                ]
        );

        $this->add_control(
                'testimonials_slider_item', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('We Are Solustrid', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Choose Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Dolor sitam consectetur sed adipisicing eiusmod tempor cididunt laboret mag magn aliquat enim sed minim veniam nostrud lorem ipsum dolor.', 'solustrid-core')
                ],
                [
                    'name' => 'client_name',
                    'label' => esc_html__('Client Name', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Donald Juster', 'solustrid-core')
                ],
                [
                    'name' => 'client_designation',
                    'label' => esc_html__('Client designation ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('California, USA', 'solustrid-core')
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ],
                [
                    'name' => 'extra_class',
                    'label' => esc_html__('Extra Class', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!--Testimonials Section-->
        <section class="testimonials-section">
            <div class="auto-container">
                <div class="sec-title centered">
                    <div class="sec-title centered">
                        <div class="title">
                            <?php
                            echo wp_kses_post($settings['title_1']);
                            ?>
                        </div>
                        <h2>
                            <?php
                            echo wp_kses_post($settings['title_2']);
                            ?>
                        </h2>
                    </div>
                </div>
                <div class="testimonial-carousel owl-theme owl-carousel">
                    <!--Testimonial-->
                    <?php
                    foreach ($settings['testimonials_slider_item'] as $tab) {
                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        ?>
                        <div class="testimonial-block-one">
                            <div class="inner-box">
                                <div class="upper">
                                    <div class="text"><?php echo wp_kses_post($tab['content']); ?></div>
                                    <div class="icon"><span class="flaticon-quote"></span></div>
                                </div>
                                <div class="lower">
                                    <div class="image">
                                        <img src="<?php echo esc_url($tab['image']['url']) ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                                    </div>
                                    <div class="name"> <?php echo esc_html($tab['client_name']); ?></div>
                                    <div class="location"><?php echo wp_kses_post($tab['client_designation']); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </section>
        <!--End Testimonials Section-->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new TestimonialsTwo());
