<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Offer extends Widget_Base {

    public function get_name() {
        return 'offer';
    }

    public function get_title() {
        return esc_html__('Offer', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'text_content_section', [
            'label' => esc_html__('Text Column', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'logo_image', [
            'label' => __('Logo', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('We offer Industrial Solutions that are reliable, efficient, safe and sustainable.', 'solustrid-core')
                ]
        );

        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Approach', 'solustrid-core')],
                ['tab_title' => esc_html__('Mission', 'solustrid-core')],
                ['tab_title' => esc_html__('History', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Approach', 'solustrid-core')
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('content', 'solustrid-core'),
                    'type' => Controls_Manager::WYSIWYG,
                    'default' => '<p>Incididunt ut labore et dolore magna aliqua. At enim ad minim veniam, quis nos trud exercitation ullamco laboris nisi ut aliquip ex ea comaody consequat duis aute irure dolor in reprehenderit in voluptate velit.</p>'
                ],
                [
                    'name' => 'button_title',
                    'label' => esc_html__('Button Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'About Company'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Button Link', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true,
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
                'image_content_section', [
            'label' => esc_html__('Image Column', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Image 1', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'image_1', [
            'label' => __('Image 2', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );



        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );
        $this->add_control(
                'play_box_url', [
            'label' => esc_html__('Play Box URL', 'solustrid-core'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => 'www.youtube.com/watch?v=kxPCFljwJws',
                'is_external' => '',
            ],
            'show_external' => true,
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }


        $logo_image_url = '';
        if (!empty($settings['logo_image']['id'])) {
            $logo_image_url = wp_get_attachment_image_src($settings['logo_image']['id'], $attachment_size);
            $logo_image_url = $logo_image_url[0];
        } else {
            $logo_image_url = $settings['logo_image']['url'];
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
            $image_url_1 = Group_Control_Image_Size::get_attachment_image_src($settings['image_1']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }

            if (!empty($settings['image_1']['id'])) {
                $image_src_1 = wp_get_attachment_image_src($settings['image_1']['id'], $attachment_size);
                $image_url_1 = $image_src_1[0];
            } else {
                $image_url_1 = $settings['image_1']['url'];
            }
        }
        ?>

        <!-- What We Offer Section -->
        <section class="what-we-offer">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Text Column -->
                    <div class="text-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="title-style-one alternate">
                                <div class="icon"><img src="<?php echo esc_url($logo_image_url); ?>" alt="<?php echo esc_html__('Image', 'solustrid-core') ?>"></div>
                                <div class="subtitle"><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?></h2>
                            </div>
                            <!--Tabs Box-->
                            <div class="tabs-box tabs-style-one">
                                <ul class="tab-buttons clearfix">
                                    <!--Tab-->
                                    <?php
                                    foreach ($settings['countertex_tabs_tab'] as $key => $tab) {
                                        $activeClass = '';
                                        if ($key == 0) {
                                            $activeClass = 'active-btn';
                                        }
                                        ?>
                                        <li class="tab-btn <?php echo $activeClass; ?>" data-tab="#tab-<?php echo $key + 1; ?>">
                                            <div class="icon"><span class="icon-star"></span></div>
                                            <div class="txt"> <?php
                                                echo wp_kses_post($tab['tab_title']);
                                                ?></div>
                                        </li>
                                    <?php }
                                    ?>

                                </ul>
                                <div class="tabs-content">
                                    <!--Tab-->
                                    <?php
                                    foreach ($settings['countertex_tabs_tab'] as $key => $tab) {
                                        $url = '#';
                                        $target = '';
                                        if (!empty($tab['action_link'])) {
                                            $link = $tab['action_link'];
                                            $url = $link['url'];
                                            $target = $link['is_external'] ? 'target="_blank"' : '';
                                        }

                                        $activeClass = '';
                                        if ($key == 0) {
                                            $activeClass = 'active-tab';
                                        }
                                        ?>
                                        <div class="tab <?php echo $activeClass; ?>" id="tab-<?php echo $key + 1; ?>">
                                            <?php
                                            echo wp_kses_post($tab['content']);
                                            ?>
                                            <div class="link-box"><a href="<?php echo esc_url($url); ?>" class="read-more">
                                                    <?php echo wp_kses_post($tab['button_title']); ?>
                                                    <span class="fas fa-angle-right"></span></a>
                                            </div>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Image Column -->
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner clearfix">
                            <figure class="image-1 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_html__('Image', 'solustrid-core') ?>">
                            </figure>
                            <figure class="image-2 video-box wow fadeInLeft" data-wow-delay="500ms" data-wow-duration="1500ms">
                                <img src="<?php echo esc_url($image_url_1); ?>" alt="<?php echo esc_html__('Image', 'solustrid-core') ?>">
                                <!--Play Box-->
                                <?php
                                $youtubeUrl = $settings['play_box_url']['url'];
                                if (!$youtubeUrl) {
                                    $youtubeUrl = '#';
                                }
                                ?>
                                <a href="<?php echo esc_url($youtubeUrl); ?>" class="overlay-link lightbox-image">
                                    <div class="play-box-two"><span class="icon-outer"><span class="icon flaticon-play-button"><i class="ripple"></i></span></span></div>
                                </a>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End What We Offer -->

        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Offer());
