<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class featuredProjects extends Widget_Base {

    public function get_name() {
        return 'featuredProjects';
    }

    public function get_title() {
        return esc_html__('Featured Projects', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_fproject', [
            'label' => esc_html__('Featured Projects', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'bg_image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Featured Projects', 'solustrid-core')
                ]
        );

        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 6
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => 'solustrid_projects',
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        $image_url = $settings['bg_image']['url'];
        ?>
        <!-- Quote Section -->
        <section class="featured-section" style="background-image:url(<?php echo esc_url($image_url); ?>);">
            <div class="auto-container">
                <div class="content-box wow fadeInLeftBig" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="title">
                        <h2>
                            <?php
                            echo wp_kses_post($settings['title']);
                            ?>
                        </h2>
                    </div>
                    <div class="featured-project-carousel owl-theme owl-carousel">
                        <?php
                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="slide-item">
                                    <h3><?php the_title(); ?></h3>
                                    <div class="text"><?php the_excerpt(); ?></div>
                                    <a href="<?php echo esc_url(the_permalink()); ?>" class="read-more"><?php echo esc_html__('view detail', 'solustrid-core'); ?>  <span class="arrow fas fa-angle-right"></span></a>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Quote Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new featuredProjects());
