<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Aboutindustry2 extends Widget_Base {

    public function get_name() {
        return 'aboutindustry2';
    }

    public function get_title() {
        return esc_html__('About Industry 2', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'industry_section', [
            'label' => esc_html__('About Industry 2', 'solustrid-core'),
                ]
        );
        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'About Industry'
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Content 1', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => '<p>Incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nos-trud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit. Sunt in culpa qui officia deser mollit anim id est laborum unde omnis iste natus.</p>'
                ]
        );

        $this->add_control(
                'content_1', [
            'label' => esc_html__('Content 2', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => '<li>Leading industrial solutions with best machinery</li> <li>Voluptatem acusantium doloremque laudantium totam</li>     <li>Aperiam, eaque ipsa quae ab illo inventore veritatis</li>    <li>Quasi architecto beatae vitae dicta sunt explicabo</li>'
                ]
        );

        $this->add_control(
                'singnatur_image', [
            'label' => __('Singnatur Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title_sing', [
            'label' => esc_html__('Signature Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Daniel Ricardo', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Big Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );


        $this->add_control(
                'image_1', [
            'label' => __('Big Image 1', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }

        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }

        $singnatur_image = $settings['singnatur_image']['url'];

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
            $image_url_1 = Group_Control_Image_Size::get_attachment_image_src($settings['image_1']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }
            if (!empty($settings['image_1']['id'])) {
                $image_src_1 = wp_get_attachment_image_src($settings['image_1']['id'], $attachment_size);
                $image_url_1 = $image_src_1[0];
            } else {
                $image_url_1 = $settings['image_1']['url'];
            }
        }
        ?>
        <!-- About Industry Section -->
        <section class="about-industry-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <!-- Sec Title -->
                            <div class="sec-title wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="title">
                                    <?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?>
                                </div>
                                <h2>
                                    <?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?>
                                </h2>
                            </div>
                            <div class="text wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <?php
                                echo wp_kses_post($settings['content']);
                                ?>
                            </div>
                            <ul class="list-style-one wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <?php
                                echo wp_kses_post($settings['content_1']);
                                ?>
                            </ul>
                            <div class="signature-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="signature">
                                    <img src="<?php echo esc_url($singnatur_image); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                                </div>
                                <div class="ceo">
                                    <?php
                                    echo wp_kses_post($settings['title_sing']);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Images Column -->
                    <div class="images-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="row clearfix">
                                <div class="column col-lg-6 col-md-6 col-sm-12">
                                    <div class="image wow fadeInDown" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                                    </div>
                                </div>
                                <div class="column col-lg-6 col-md-6 col-sm-12">
                                    <div class="image wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <img src="<?php echo esc_url($image_url_1); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End About Industry Block -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Aboutindustry2());
