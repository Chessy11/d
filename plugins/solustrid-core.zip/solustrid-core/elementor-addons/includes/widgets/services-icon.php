<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class services extends Widget_Base {

    public function get_name() {
        return 'services';
    }

    public function get_title() {
        return esc_html__('Services Icon', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'services_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 4', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'icon',
                    'label' => esc_html__('Icon', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'flaticon-drill-3'
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Well Maintained'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Puis nostrud exercitation ullamco laboris nisi utm aliquip sed duis aute.'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'wokiee-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ],
                [
                    'name' => 'delay_time',
                    'label' => esc_html__('Delay Time', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 0
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->add_control(
                'section_class', [
            'label' => esc_html__('Section Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!-- Services Section -->
        <section class="services-section <?php echo esc_attr($settings['section_class']); ?>">
            <div class="auto-container">
                <div class="row clearfix">
                    <?php
                    foreach ($settings['services_tabs_tab'] as $tab) {
                        $dataDelay = $tab['delay_time'];
                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        ?>
                        <!-- Services Block -->
                        <div class="services-block col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-box wow fadeInUp" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="1500ms">
                                <div class="big-icon flaticon-settings-4"></div>
                                <div class="icon-box">
                                    <span class="icon <?php
                                    echo esc_attr($tab['icon']);
                                    ?>">
                                    </span>
                                </div>
                                <h3>
                                    <a href="<?php echo esc_url($url); ?>">
                                        <?php
                                        echo wp_kses_post($tab['title']);
                                        ?>
                                    </a>
                                </h3>
                                <div class="text">
                                    <?php
                                    echo wp_kses_post($tab['content']);
                                    ?></div>
                                <a class="arrow" href="<?php echo esc_url($url); ?>"><span class="icon flaticon-next"></span></a>
                            </div>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </section>
        <!-- End Services Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new services());
