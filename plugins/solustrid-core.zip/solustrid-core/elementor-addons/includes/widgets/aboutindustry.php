<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Aboutindustry extends Widget_Base {

    public function get_name() {
        return 'aboutindustry';
    }

    public function get_title() {
        return esc_html__('About Industry', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'industry_section', [
            'label' => esc_html__('Industry', 'solustrid-core'),
                ]
        );
        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'About Industry'
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__('Dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Choose Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'image_1', [
            'label' => __('Singnatur Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title_sing', [
            'label' => esc_html__('Signature Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Daniel Ricardo', 'solustrid-core')
                ]
        );


        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }

        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
            $image_url_1 = Group_Control_Image_Size::get_attachment_image_src($settings['image_1']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }
            if (!empty($settings['image_1']['id'])) {
                $image_src_1 = wp_get_attachment_image_src($settings['image_1']['id'], $attachment_size);
                $image_url_1 = $image_src_1[0];
            } else {
                $image_url_1 = $settings['image_1']['url'];
            }
        }
        ?>
        <!-- Fluid Section One -->
        <section class="fluid-section-one">
            <div class="outer-container clearfix">
                <!--Image Column-->
                <div class="image-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image:url(<?php echo esc_url($image_url); ?>);">
                    <figure class="image-box">
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                    </figure>
                </div>
                <!--Content Column-->
                <div class="content-column">
                    <div class="inner-column">
                        <!-- Sec Title -->
                        <div class="sec-title">
                            <div class="title"><?php
                                echo wp_kses_post($settings['title_1']);
                                ?></div>
                            <h2>
                                <?php
                                echo wp_kses_post($settings['title_2']);
                                ?>
                            </h2>
                        </div>
                        <?php
                        echo wp_kses_post($settings['content']);
                        ?>
                        <!-- Signature Box -->
                        <div class="signature-box">
                            <h4><?php
                                echo wp_kses_post($settings['title_sing']);
                                ?></h4>
                            <div class="signature-img">
                                <img src="<?php echo esc_url($image_url_1); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Fluid Section One -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Aboutindustry());
