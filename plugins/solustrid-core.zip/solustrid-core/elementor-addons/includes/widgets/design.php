<?php

use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class design extends \Elementor\Widget_Base {

    public function get_name() {
        return 'design';
    }

    public function get_title() {
        return esc_html__('Design', 'solustrid');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_section', [
            'label' => __('Content', 'solustrid'),
                ]
        );

        $this->add_control(
                'header_little', [
            'label' => __('Title 1', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('We Are Solustrid', 'solustrid'),
            'dynamic' => ['active' => true]
                ]
        );

        $this->add_control(
                'header_big', [
            'label' => __('Title 2', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Since 1975, <br> Engineering Design <br> and Consultancy',
            'dynamic' => ['active' => true]
                ]
        );

        $this->add_control(
                'content_block', [
            'label' => __('Content 1', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('Consectetur adipisicing elit sed eiusmod tempor dolor veniam quis nostrud ullamco sed aequat dolore magna aliqua labore veniam quis nostrud exercitation.', 'solustrid-core'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'content', [
            'label' => __('Content 2', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('Proident, sunt in culpa qui officia deserunt mollit anim id est laborum sedu perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperid amd eaque ipsa quae ab illo inventore veritatis et quasi architecto.', 'solustrid-core'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'icons', [
            'label' => __('Icons', 'solustrid'),
            'type' => \Elementor\Controls_Manager::ICON,
            'include' => [
                'icon flaticon-garbage-truck',
                'icon flaticon-helmet-2',
                'icon flaticon-manufacture-1',
            ],
            'default' => 'flaticon-garbage-truck'
                ]
        );

        $this->add_control(
                'items', [
            'label' => __('Icon List', 'solustrid'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'list_title' => __('Title #1', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ],
                [
                    'list_title' => __('Title #2', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ],
                [
                    'list_title' => __('Title #3', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ]
            ],
                ]
        );

        $repeater2 = new \Elementor\Repeater();

        $repeater2->add_control(
                'image_header_little', [
            'label' => __('Image Tittle 1', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('Feature 1', ''),
            'dynamic' => ['active' => true]
                ]
        );

        $repeater2->add_control(
                'image_header_big', [
            'label' => __('Image Tittle 2', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('Experts Engineers Support', 'solustrid'),
            'dynamic' => ['active' => true]
                ]
        );

        $repeater2->add_control(
                'image_subtitle', [
            'label' => __('Image Content', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __('Nostrud sed ullamco laboris', 'solustrid'),
            'dynamic' => ['active' => true]
                ]
        );

        $repeater2->add_control(
                'content_image', [
            'label' => __('Content Hover ', 'solustrid'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('Auis nostrud exercitation ullamco laboris aliquip ex bea sed consequat duis autes ur dolore magna aliqua ad minim.', 'solustrid'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $repeater2->add_control(
                'images', [
            'label' => __('Images', 'solustrid'),
            'type' => \Elementor\Controls_Manager::ICON,
            'default' => __('flaticon-constructor-with-hard-hat-protection-on-his-head', 'solustrid-core'),
                ]
        );

        $repeater2->add_control(
                'delay_time', [
            'label' => esc_html__('Delay Time', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '0'
                ]
        );

        $this->add_control(
                'items2', [
            'label' => __('Repeater List', 'solustrid'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater2->get_controls(),
            'default' => [
                [
                    'list_title' => __('Title #1', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ],
                [
                    'list_title' => __('Title #2', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ],
                [
                    'list_title' => __('Title #3', 'solustrid'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid'),
                ]
            ],
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="design-section">
            <div class="auto-container">
                <!-- Upper Section -->
                <div class="upper-section">
                    <div class="row clearfix">
                        <!-- Title Column -->
                        <div class="title-column col-lg-5 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <!-- Sec Title -->
                                <div class="sec-title wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="title"><?php echo $settings['header_little']; ?></div>
                                    <h2><?php echo $settings['header_big']; ?></h2>
                                </div>
                            </div>
                        </div>
                        <!-- Content Column -->
                        <div class="content-column col-lg-7 col-md-12 col-sm-12">
                            <div class="inner-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="icons-box">
                                    <?php foreach ($settings['items'] as $item) { ?>
                                        <span class="<?php echo $item['icons']; ?>"></span>
                                    <?php } ?>
                                </div>
                                <div class="bold-text"><?php echo $settings['content_block']; ?></div>
                                <div class="text"><?php echo $settings['content']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Lower Section -->
                <div class="lower-section">
                    <div class="clearfix">
                        <!-- Feature Block Two -->
                        <?php
                        foreach ($settings['items2'] as $item) {
                            $dataDelay = $item['delay_time'];
                            ?>
                            <div class="feature-block-two col-lg-4 col-md-6 col-sm-12">
                                <div class="inner-box wow fadeInUp" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="1500ms">
                                    <div class="side-icon <?php echo $item['images']; ?>"></div>
                                    <div class="content">
                                        <div class="title"><?php echo $item['image_header_little']; ?></div>
                                        <h3><?php echo $item['image_header_big']; ?></h3>
                                        <div class="sub-title"><?php echo $item['image_subtitle']; ?></div>
                                    </div>
                                    <!-- Overlay Box -->
                                    <div class="overlay-box">
                                        <div class="overlay-inner">
                                            <div class="overlay-content">
                                                <div class="title-two"><?php echo $item['image_header_little']; ?></div>
                                                <h4><a href="#"><?php echo $item['image_header_big']; ?></a></h4>
                                                <div class="text"><?php echo $item['content_image']; ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new design());
