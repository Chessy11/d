<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Contact extends Widget_Base {

    public function get_name() {
        return 'contact';
    }

    public function get_title() {
        return esc_html__('Contact', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_contact', [
            'label' => esc_html__('Contact Info', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Contact Details', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Get in touch with us for any questions about our industries or projects.'
                ]
        );


        $this->add_control(
                'office_address', [
            'label' => esc_html__('Office Address', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => '73 Ringer House Lane, Dynatis Newyork 33022, USA'
                ]
        );
        $this->add_control(
                'factory_address', [
            'label' => esc_html__('Factory Address', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Suite # 140 Belfast Ave, Trendys Florida 33022, USA'
                ]
        );

        $this->add_control(
                'email', [
            'label' => esc_html__('Email', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'solustrid@example.com'
                ]
        );

        $this->add_control(
                'support', [
            'label' => esc_html__('Call Support', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '+(345) 206 7849'
                ]
        );

        $this->add_control(
                'social_link', [
            'label' => esc_html__('Solical Link', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'section_form', [
            'label' => esc_html__('Form Content', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'comr_title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );


        $this->add_control(
                'form_title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Send a Message'
                ]
        );

        $this->add_control(
                'cf7_code', [
            'label' => esc_html__('Contact Form 7 Shortcode', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA
                ]
        );

        $this->add_control(
                'form_extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!-- Contact Page Section -->
        <section class="contact-page-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!-- Info Column -->
                    <div class="info-column col-lg-4 col-md-12 col-sm-12">
                        <div class="inner-column wow fadeInLeft" data-wow-delay="0ms">
                            <!-- Title Box -->
                            <div class="title-box">
                                <h3><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></h3>
                                <div class="title-text"><?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?></div>
                            </div>
                            <ul class="contact-info-list">
                                <li>
                                    <span class="icon icon-home"></span><strong><?php echo esc_html__('Head Office', 'solustrid-core') ?></strong><?php
                                    echo wp_kses_post($settings['office_address']);
                                    ?>
                                </li>
                                <li>
                                    <span class="icon icon-location-pin"></span><strong><?php echo esc_html__('Factory Address', 'solustrid-core') ?></strong><?php
                                    echo wp_kses_post($settings['factory_address']);
                                    ?>
                                </li>
                                <li><span class="icon icon-envelope-open"></span><strong><?php echo esc_html__('Email us', 'solustrid-core') ?></strong><?php
                                    echo wp_kses_post($settings['email']);
                                    ?>
                                </li>
                                <li><span class="icon icon-call-in"></span><strong><?php echo esc_html__('Call Support', 'solustrid-core') ?></strong><?php
                                    echo wp_kses_post($settings['support']);
                                    ?>
                                </li>
                            </ul>

                            <?php
                            echo wp_kses_post($settings['social_link']);
                            ?>
                        </div>
                    </div>

                    <!-- Form Column -->
                    <div class="form-column col-lg-8 col-md-12 col-sm-12">
                        <div class="inner-column wow fadeInRight" data-wow-delay="0ms">
                            <!-- Sec Title -->
                            <div class="sec-title">
                                <div class="title">
                                    <?php
                                    echo wp_kses_post($settings['comr_title_1']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['form_title_2']);
                                    ?>
                                </h2>
                            </div>
                            <!-- Contact Form -->
                            <div class="contact-form">
                                    <?php
                                    echo do_shortcode($settings['cf7_code']);
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Contact());
