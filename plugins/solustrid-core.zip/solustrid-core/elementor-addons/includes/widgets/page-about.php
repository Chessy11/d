<?php

namespace wokiee\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class PageAbout extends Widget_Base {

    public function get_name() {
        return 'page_about';
    }

    public function get_title() {
        return esc_html__('About Page', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'innovation_section', [
            'label' => esc_html__('Innovation', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We are committed to provide safe <br>industrial solutions to many factories'
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Description', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'At Solustrid, Our goal is to generate oriented sales by our staff  members which enables us to meet the clients expectations in timely manner ipsum dolor sit amet consectetur adipisicing elit sed ipsum eiusmod tempor incididunt labore'
                ]
        );


        $this->add_control(
                'content_2', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => '<p><strong>Consectetur adipisicing elit sed do eiusmod tempor dolor magna aliquat enim veniam quis nostrud exercitation ullamco consequat.</strong></p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis node trud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit.</p>'
                ]
        );


        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Counter 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'counter_text',
                    'label' => esc_html__('Counter Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '25'
                ],
                [
                    'name' => 'unit_text',
                    'label' => esc_html__('Counter Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                ],
                [
                    'name' => 'counter_title',
                    'label' => esc_html__('Counter Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Industries Served'
                ],
                [
                    'name' => 'data_speed',
                    'label' => esc_html__('Data Speed', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '2000'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );


        $this->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );


        $this->add_control(
                'image_logo', [
            'label' => __('Logo Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'image_1', [
            'label' => __('Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }


        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
            $image_url_1 = Group_Control_Image_Size::get_attachment_image_src($settings['image_1']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }

            if (!empty($settings['image_1']['id'])) {
                $image_src_1 = wp_get_attachment_image_src($settings['image_1']['id'], $attachment_size);
                $image_url_1 = $image_src_1[0];
            } else {
                $image_url_1 = $settings['image_1']['url'];
            }

            $image_logo = $settings['image_logo']['url'];
        }
        ?>

        <!-- Fun Facts Section -->
        <section class="about-section-two" style="background-image:url(<?php echo esc_url($image_url); ?>);">
            <div class="auto-container">
                <div class="title-style-one style-two centered">
                    <div class="icon"><img src="<?php echo esc_url($image_logo); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"></div>
                    <div class="subtitle"><?php
                        echo wp_kses_post($settings['title_1']);
                        ?></div>
                    <h2><?php
                        echo wp_kses_post($settings['title_2']);
                        ?></h2>
                    <div class="text"><?php
                        echo wp_kses_post($settings['content']);
                        ?></div>
                </div>

                <div class="row">
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <figure class="image"><a href="<?php echo esc_url($image_url_1); ?>" class="lightbox-image">
                                    <img src="<?php echo esc_url($image_url_1); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>">
                                </a>
                            </figure> 
                        </div>
                    </div>

                    <div class="content-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="text">
                                <?php
                                echo wp_kses_post($settings['content_2']);
                                ?>
                            </div>
                            <div class="fact-counter wow fadeInRightBig" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="clearfix">
                                    <?php foreach ($settings['countertex_tabs_tab'] as $tab) { ?>
                                        <!--Column-->
                                        <div class="column counter-column col-lg-4 col-md-4 col-sm-12">
                                            <div class="inner">
                                                <div class="count-outer count-box">
                                                    <span class="count-text" data-speed="<?php
                                                    echo esc_attr($tab['data_speed']);
                                                    ?>" data-stop="<?php
                                                          echo wp_kses_post($tab['counter_text']);
                                                          ?>">0</span><?php
                                                          if ($tab['unit_text']) {
                                                              echo wp_kses_post($tab['unit_text']);
                                                          }
                                                          ?>
                                                    <h4 class="counter-title"><?php
                                                        echo wp_kses_post($tab['counter_title']);
                                                        ?></h4>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Fun Facts Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new PageAbout());
