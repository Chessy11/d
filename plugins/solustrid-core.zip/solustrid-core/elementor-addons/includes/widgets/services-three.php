<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class ServicesThree extends Widget_Base {

    public function get_name() {
        return 'custom_services_3';
    }

    public function get_title() {
        return esc_html__('Services Three', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Heading Content', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Services For Industries', 'solustrid-core')
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
                'section_block', [
            'label' => esc_html__('Service Content', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Service 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 3', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 4', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 5', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 6', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ]
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Mining & Drilling'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Auis nostrud exercitation ullamc laboris nisitm aliquip ex bea sed consequat duis autes ure dolor. dolore magna aliqua nim ad minim.'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true,
                ],
                [
                    'name' => 'delay_time',
                    'label' => esc_html__('Delay Time', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 0
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!-- Industries Section -->
        <section class="industries-section">
            <div class="auto-container">
                <!-- Big Icon -->
                <div class="big-icon flaticon-settings-4"></div>
                <!-- Sec Title -->
                <div class="sec-title centered light">
                    <div class="title">
                        <?php
                        echo wp_kses_post($settings['title_1']);
                        ?>
                    </div>
                    <h2>
                        <?php
                        echo wp_kses_post($settings['title_2']);
                        ?>
                    </h2>
                </div>
                <div class="row clearfix">
                    <?php
                    foreach ($settings['countertex_tabs_tab'] as $tab) {
                        $dataDelay = $tab['delay_time'];
                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        $image_url = $tab['image']['url'];
                        ?>
                        <!-- Industry Block -->
                        <div class="industry-block col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <div class="icon-box wow zoomIn" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="2000ms">
                                    <span class="icon">
                                        <img src="<?php echo esc_url($image_url); ?>" alt= "<?php echo esc_html__('Image', 'solustrid-core') ?>"/>
                                    </span>
                                </div>
                                <h3>
                                    <a href="<?php echo esc_url($url); ?>"><?php
                                        echo wp_kses_post($tab['title']);
                                        ?>
                                    </a>
                                </h3>
                                <div class="text">
                                    <?php
                                    echo wp_kses_post($tab['content']);
                                    ?>
                                </div>
                                <a class="read-more" href="<?php echo esc_url($url); ?>"><?php echo esc_html__('Read More', 'solustrid-core'); ?> <span class="icon fas fa-angle-right"></span></a>
                            </div>
                        </div>
                        <!--End Industry Block -->
                    <?php }
                    ?>
                </div>
            </div>
        </section>
        <!-- End Industries Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new ServicesThree());
