<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Blogs extends Widget_Base {

    public function get_name() {
        return 'blogs';
    }

    public function get_title() {
        return esc_html__('Blog', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    private function get_blog_categories() {
        $options = array();
        $taxonomy = 'category';
        if (!empty($taxonomy)) {
            $terms = get_terms(
                    array(
                        'parent' => 0,
                        'taxonomy' => $taxonomy,
                        'hide_empty' => false,
                    )
            );
            if (!empty($terms)) {
                foreach ($terms as $term) {
                    if (isset($term)) {
                        $options[''] = 'Select';
                        if (isset($term->slug) && isset($term->name)) {
                            $options[$term->slug] = $term->name;
                        }
                    }
                }
            }
        }
        return $options;
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Blogs', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Industrial News', 'solustrid-core')
                ]
        );

        $this->add_control(
                'category_id', [
            'type' => \Elementor\Controls_Manager::SELECT,
            'label' => esc_html__('Category', 'solustrid-core'),
            'options' => $this->get_blog_categories()
                ]
        );

        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__(3, 'solustrid-core')
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'delay_time', [
            'label' => esc_html__('Delay Time', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '400'
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $delay_time = $settings['delay_time'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => array('post'),
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'category_name' => $settings['category_id'],
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        ?>

        <!-- News Section -->
        <section class="news-section">
            <div class="auto-container">
                <!-- Sec Title -->
                <div class="sec-title centered">
                    <div class="title">
                        <?php
                        echo wp_kses_post($settings['title_1']);
                        ?>
                    </div>
                    <h2>
                        <?php
                        echo wp_kses_post($settings['title_2']);
                        ?>
                    </h2>
                </div>
                <div class="row clearfix">
                    <?php
                    $i = 0;
                    if ($query->have_posts()) {
                        while ($query->have_posts()) {
                            $dataDelay = ((int) $delay_time ) * $i;
                            $query->the_post();
                            ?>
                            <!-- News Block -->
                            <div class="news-block col-lg-4 col-md-6 col-sm-12">
                                <div class="inner-box wow fadeInUp" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="1500ms">
                                    <div class="image">
                                        <?php
                                        $solustrid_pmeta_image = get_post_meta(get_the_ID(), 'framework-meta-image', TRUE);
                                        $solustrid_image_src = wp_get_attachment_image_src($solustrid_pmeta_image, 'full');
                                        ?>
                                        <a href="<?php the_permalink(); ?>">
                                            <img class="lazyload" src="<?php echo SOLUSTRID_IMG_URL . 'solustrid-load.svg' ?>" data-src="<?php echo esc_url($solustrid_image_src[0]); ?>" alt="<?php echo esc_attr('Alt'); ?>" />
                                        </a>
                                    </div>
                                    <div class="lower-content">
                                        <?php
                                        the_title('<h3><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h3>');
                                        ?>
                                        <div class="post-date">
                                            <?php
                                            solustrid_posted_on();
                                            solustrid_posted_by();
                                            ?>
                                        </div>
                                        <a class="arrow" href="<?php echo esc_url(get_permalink()); ?>"><span class="icon flaticon-next"></span></a>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $i++;
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </div>
            </div>
        </section>
        <!-- End News Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Blogs());
