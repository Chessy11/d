<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Brands2 extends Widget_Base {

    public function get_name() {
        return 'brands2';
    }

    public function get_title() {
        return esc_html__('Brands 2', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'brand_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 4', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 5', 'solustrid-core')],
                ['tab_title' => esc_html__('Item 6', 'solustrid-core')],
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'size',
                    'label' => esc_html__('Select Size', 'solustrid-core'),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'full',
                    'options' => [
                        'full' => esc_html__('Full', 'solustrid-core'),
                        'custom' => esc_html__('Custom', 'solustrid-core')
                    ]
                ],
                [
                    'name' => 'width',
                    'label' => esc_html__('Width', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'size' => 'custom',
                    ],
                ],
                [
                    'name' => 'height',
                    'label' => esc_html__('Height', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'size' => 'custom',
                    ],
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ],
                [
                    'name' => 'extra_class',
                    'label' => esc_html__('Extra Class', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!-- Sponsors Section -->
        <section class="sponsors-section alternate">
            <div class="auto-container">
                <div class="factories-icons-carousel owl-carousel owl-theme">
                    <?php
                    foreach ($settings['brand_tabs_tab'] as $tab) {
                        $attachment_size = array();
                        $has_custom_size = FALSE;
                        if (!empty($tab['width']) && !empty($tab['height'])) {
                            $has_custom_size = true;
                            $attachment_size[0] = (int) $tab['width'];
                            $attachment_size[1] = (int) $tab['height'];
                        }

                        if (!$has_custom_size) {
                            $attachment_size = 'full';
                        }

                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        if (is_array($attachment_size)) {
                            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $tab['width'], 'height' => (int) $tab['height']]];
                            $image_url = Group_Control_Image_Size::get_attachment_image_src($tab['image']['id'], 'image', $instance);
                        } else {
                            if (!empty($tab['image']['id'])) {
                                $image_src = wp_get_attachment_image_src($tab['image']['id'], $attachment_size);
                                $image_url = $image_src[0];
                            } else {
                                $image_url = $tab['image']['url'];
                            }
                        }
                        ?>
                        <div class="logo">
                            <a href="<?php echo esc_url($url); ?>">
                                <img src="<?php echo esc_url($image_url); ?>" alt= "<?php echo esc_html__('Image', 'solustrid-core') ?>"/>
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>
        <!-- End Factory Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Brands2());
