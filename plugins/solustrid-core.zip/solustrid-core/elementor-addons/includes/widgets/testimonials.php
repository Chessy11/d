<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Testimonials extends Widget_Base {

    public function get_name() {
        return 'testimonials_carousel';
    }

    public function get_title() {
        return esc_html__('Testimonials', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'show_bg_image', [
            'label' => __('Background Icon', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => __('Show', 'solustrid-core'),
            'label_off' => __('Hide', 'solustrid-core'),
            'return_value' => 'yes',
            'default' => 'yes',
                ]
        );

        $this->add_control(
                'section_style', [
            'label' => __('Testimonials Style', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1' => __('1', 'solustrid-core'),
                '2' => __('2', 'solustrid-core'),
            ],
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Client’s Reviews'
                ]
        );

        $this->add_control(
                'testimonials_slider_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Testimonials', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('We Are Solustrid', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Choose Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Since vindictively over agile the some far well besides constructively well airy then one during with close excellent grabbed gosh contrary far dalmatian upheld intrepid bought and toucan majestic more some apart dear boa much cast falcon a dwelled ouch busy.'
                ],
                [
                    'name' => 'client_name',
                    'label' => esc_html__('Client Name', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('James Shane Well', 'solustrid-core')
                ],
                [
                    'name' => 'client_designation',
                    'label' => esc_html__('Client designation ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('California, USA', 'solustrid-core')
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $section_style = '';
        if ('2' === $settings['section_style']) {
            $section_style = 'style-two';
        }
        ?>
        <!-- Clients Section -->
        <!-- style-two-->
        <section class="clients-section <?php echo esc_attr($section_style); ?>">
            <div class="auto-container">
                <?php
                if ('yes' === $settings['show_bg_image']) {
                    echo '<div class="logo-icon flaticon-settings-4"></div>';
                }
                ?>
                <!-- Sec Title -->
                <div class="sec-title centered">
                    <div class="title">
                        <?php
                        echo wp_kses_post($settings['title_1']);
                        ?>
                    </div>
                    <h2>
                        <?php
                        echo wp_kses_post($settings['title_2']);
                        ?>
                    </h2>
                </div>
                <div class="single-item-carousel owl-carousel owl-theme">
                    <?php
                    foreach ($settings['testimonials_slider_item'] as $tab) {
                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        ?>

                        <div class="testimonial-block">
                            <div class="inner-box">
                                <div class="image-outer">
                                    <!-- Quote Left -->
                                    <div class="quote quote-left">
                                        <span class="icon flaticon-right-quotation-sign"></span>
                                    </div>
                                    <!-- Quote Right -->
                                    <div class="quote quote-right">
                                        <span class="icon flaticon-right-quotation-sign"></span>
                                    </div>
                                    <div class="image">
                                        <img src="<?php echo esc_url($tab['image']['url']) ?>" alt= "<?php echo esc_attr__('Image', 'solustrid-core'); ?>" />
                                    </div>
                                </div>
                                <div class="text"><?php echo wp_kses_post($tab['content']); ?></div>
                                <h3> <?php echo esc_html($tab['client_name']); ?></h3>
                                <div class="location"><?php echo wp_kses_post($tab['client_designation']); ?></div>
                            </div>
                        </div>
                    <?php }
                    ?>

                </div>
            </div>
        </section>
        <!-- End Clients Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Testimonials());
