<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Quote extends Widget_Base {

    public function get_name() {
        return 'quote';
    }

    public function get_title() {
        return esc_html__('Quotattion', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'quote_section', [
            'label' => esc_html__('Quotation', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Get A Free Quote For Industrial Project', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We always bring good quality services with 100% safety measuresF'
                ]
        );


        $this->add_control(
                'button_text', [
            'label' => esc_html__('Button Text', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'Get A Quote'
                ]
        );

        $this->add_control(
                'action_link', [
            'label' => __('Action Button', 'solustrid-core'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => '#',
                'is_external' => '',
            ],
            'show_external' => true,
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }
        ?>
        <!-- Quote Section -->
        <section class="quote-section wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
            <div class="auto-container">
                <div class="inner-section">
                    <div class="clearfix">
                        <div class="pull-left">
                            <div class="content">
                                <div class="icon flaticon-hammer"></div>
                                <h3><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></h3>
                                <div class="text"><?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?></div>
                            </div>
                        </div>
                        <div class="pull-right">
                            <a href="<?php echo esc_url($url); ?>" <?php echo $target; ?> class="theme-btn btn-style-three"><?php
                                echo wp_kses_post($settings['button_text']);
                                ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Quote Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Quote());
?>
