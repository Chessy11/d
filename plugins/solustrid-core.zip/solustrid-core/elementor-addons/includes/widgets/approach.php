<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Approach extends Widget_Base {

    public function get_name() {
        return 'approach';
    }

    public function get_title() {
        return esc_html__('Approach', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'bg_image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'image_logo', [
            'label' => __('Logo Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'We are Solustrid'
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'A Different Approach'
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Incididunt ut labore et dolore magnas aliqua enim ad minim veniam quis node trud exercitation ullamco laboris nisi ut aliquip ex ea commodo duis consequat aute irure dolor in reprehenderit in voluptate velit.'
                ]
        );


        $this->add_control(
                'faq_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Taqs Item', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'icon',
                    'label' => __('Icon', 'solustrid-core'),
                    'type' => \Elementor\Controls_Manager::ICON,
                    'default' => 'icon flaticon-market',
                    'include' => [
                        'icon flaticon-nuclear-plant',
                        'icon flaticon-factory',
                        'icon flaticon-engineer'
                    ],
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Renewable Energy Production'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Veniam quis node exercitation ullamco nisi aliquip laboris'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('URL', 'solustrid-core'),
                    'type' => \Elementor\Controls_Manager::URL,
                    'show_external' => true,
                    'default' => [
                        'url' => '#',
                        'is_external' => true,
                        'nofollow' => true,
                    ],
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $image_logo_url = isset($settings['image_logo']['url']) ? $settings['image_logo']['url'] : '#';
        $image_url = isset($settings['image']['url']) ? $settings['image']['url'] : '#';
        $bg_image_url = isset($settings['bg_image']['url']) ? $settings['bg_image']['url'] : '#';
        ?>
        <!-- Approach Section -->
        <section class="approach-section" style="background-image: url(<?php echo esc_url($bg_image_url); ?>); ">
            <div class="auto-container">
                <div class="row">
                    <!-- Content Column -->
                    <div class="content-column col-lg-6 col-md-12 col-sm-12 order-2">
                        <div class="inner-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <!-- Sec Title -->
                            <div class="sec-title">
                                <div class="icon">
                                    <img src="<?php echo esc_url($image_logo_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"/>
                                </div>
                                <div class="title"><?php
                                    echo wp_kses_post($settings['title']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></h2>
                                <div class="text">
                                    <?php
                                    echo wp_kses_post($settings['content']);
                                    ?>
                                </div>
                            </div>
                            <?php
                            foreach ($settings['faq_item'] as $tab) {

                                $url = '#';
                                $target = '';
                                if (!empty($tab['action_link'])) {
                                    $link = $tab['action_link'];
                                    $url = $link['url'];
                                    $target = $link['is_external'] ? 'target="_blank"' : '';
                                }
                                ?>
                                <!-- Approach Block -->
                                <div class="approach-block">
                                    <div class="inner-box">
                                        <div class="icon-box"><span class="<?php echo esc_attr($tab['icon']); ?>"></span></div>
                                        <h4><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($tab['title']); ?></a></h4>
                                        <div class="text"><?php echo wp_kses_post($tab['content']); ?></div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <!-- Image Column -->
                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <figure class="image">
                                <a href="<?php echo esc_url($image_url); ?>" class="lightbox-image">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"/>
                                </a>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Approach Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Approach());
?>
