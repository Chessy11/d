<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Counter extends Widget_Base {

    public function get_name() {
        return 'counter';
    }

    public function get_title() {
        return esc_html__('Counter', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'counter_section', [
            'label' => esc_html__('Counter', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Counter 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Counter 3', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'counter_text',
                    'label' => esc_html__('Unit Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '25'
                ],
                [
                    'name' => 'unit_text',
                    'label' => esc_html__('Counter Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                ],
                [
                    'name' => 'counter_title',
                    'label' => esc_html__('Counter Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Industries Served'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>

        <div class="fact-counter">
            <div class="clearfix">
                <?php foreach ($settings['countertex_tabs_tab'] as $tab) { ?>
                    <!--Column-->
                    <div class="column counter-column col-lg-4 col-md-4 col-sm-12">
                        <div class="inner wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="count-outer count-box">
                                <span class="count-text" data-speed="2500" data-stop="<?php
                                echo esc_attr($tab['counter_text']);
                                ?>">0</span><?php
                                      if ($tab['unit_text']) {
                                          echo wp_kses_post($tab['unit_text']);
                                      }
                                      ?>
                                <h4 class="counter-title">
                                    <?php
                                    echo wp_kses_post($tab['counter_title']);
                                    ?>
                                </h4>
                            </div>
                        </div>
                    </div>

                <?php }
                ?>
            </div>
        </div>
        <?php
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Counter());
