<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class OurTeam extends Widget_Base {

    public function get_name() {
        return 'team_member';
    }

    public function get_title() {
        return esc_html__('Our Team', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'section_style', [
            'label' => __('Team Style', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1' => __('1', 'solustrid-core'),
                '2' => __('2', 'solustrid-core'),
            ],
                ]
        );

        $this->add_control(
                'column_style', [
            'label' => __('Column Item', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '3',
            'options' => [
                '4' => __('3', 'solustrid-core'),
                '3' => __('4', 'solustrid-core'),
            ],
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Board of Directors'
                ]
        );

        $this->add_control(
                'team_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Team Membar', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #4', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'client_name',
                    'label' => esc_html__('Client Name', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Daniel Ricardo', 'solustrid-core')
                ],
                [
                    'name' => 'client_designation',
                    'label' => esc_html__('Client designation ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Director & CEO'
                ],
                [
                    'name' => 'phone',
                    'label' => esc_html__('Phone', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => '+1 (234) 567 8009'
                ],
                [
                    'name' => 'email',
                    'label' => esc_html__('Email', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'ricardo@domain.com'
                ],
                [
                    'name' => 'social_icon',
                    'label' => esc_html__('Social Link', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => '<li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                 <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                 <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                 <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ],
                [
                    'name' => 'delay_time',
                    'label' => esc_html__('Delay Time', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 0
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $section_style = 'team-section';
        $team_block = 'team-block';
        if ('2' === $settings['section_style']) {
            $section_style = 'team-section-two';
            $team_block = 'team-block-two';
        }
        ?>

        <!-- Team Section -->
        <section class="<?php echo esc_attr($section_style); ?>">
            <div class="auto-container">
                <!-- Sec Title -->
                <?php
                if ('1' === $settings['section_style']) {
                    if (!empty($settings['title_1']) && !empty($settings['title_2'])) {
                        ?>
                        <div class="sec-title centered">
                            <div class="title">
                                <?php
                                echo wp_kses_post($settings['title_1']);
                                ?>
                            </div>
                            <h2>
                                <?php
                                echo wp_kses_post($settings['title_2']);
                                ?>
                            </h2>
                        </div>
                        <?php
                    }
                }
                ?>

                <div class="row">
                    <?php
                    foreach ($settings['team_item'] as $tab) {
                        $dataDelay = $tab['delay_time'];
                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        ?>
                        <!-- Team Block -->
                        <div class="<?php echo esc_attr($team_block); ?> col-lg-<?php echo esc_attr($settings['column_style']); ?> col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image">
                                        <a href="<?php echo esc_url($url) ?>">
                                            <img src="<?php echo esc_url($tab['image']['url']); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>">
                                        </a>
                                    </figure>
                                    <?php if ('2' === $settings['section_style']) { ?>
                                        <div class="overlay-box">
                                            <ul class="contact-list">
                                                <li><i class="icon icon-call-in"></i> <a href="#"><?php echo wp_kses_post($tab['phone']); ?></a></li>
                                                <li><i class="icon icon-envelope-open"></i> <a href="#"><?php echo wp_kses_post($tab['email']); ?></a></li>
                                            </ul>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                                <div class="lower-content">
                                    <h3 class="name"><a href="<?php echo esc_url($url); ?>"> <?php echo esc_html($tab['client_name']); ?></a></h3>
                                    <span class="designation"><?php echo wp_kses_post($tab['client_designation']); ?></span>
                                    <?php if ('2' === $settings['section_style']) { ?>
                                        <ul class="social-links">
                                            <?php
                                            echo wp_kses_post($tab['social_icon']);
                                            ?>
                                        </ul>
                                    <?php } else { ?>
                                        <a class="arrow" href="<?php echo esc_url($url); ?>"><span class="icon flaticon-next"></span></a>
                                        <?php }
                                        ?>
                                </div>
                            </div>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </section>
        <!--End Team Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new OurTeam());
?>