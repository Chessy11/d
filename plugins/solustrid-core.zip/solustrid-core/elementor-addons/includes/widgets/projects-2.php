<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class ProjectsTwo extends Widget_Base {

    public function get_name() {
        return 'projects-two';
    }

    public function get_title() {
        return esc_html__('Projects Two', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_project', [
            'label' => esc_html__('Projects', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Industrial News', 'solustrid-core')
                ]
        );

        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 2
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => 'solustrid_projects',
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        ?>

        <!-- Features Section Two -->
        <section class="features-section-two alternate">
            <div class="auto-container">
                <?php
                if ($query->have_posts()) {
                    $i = 1;
                    while ($query->have_posts()) {
                        $query->the_post();
                        ?>
                        <!-- Feature Block Seven -->
                        <div class="feature-block-seven <?php if ($i != 1) echo 'style-two'; ?>">
                            <div class="row clearfix">
                                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                    <div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <figure class="image-box"><a href="<?php the_post_thumbnail_url(); ?>" class="lightbox-image">
                                                <?php
                                                the_post_thumbnail();
                                                ?>
                                            </a>
                                        </figure>
                                    </div>
                                </div>
                                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                                    <div class="inner-column wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <!-- Sec Title -->
                                        <div class="sec-title">
                                            <?php
                                            $sub_title = get_post_meta(get_the_ID(), 'framework-service-sub-title', TRUE);
                                            ?>
                                            <div class="title"><?php echo esc_html($sub_title); ?></div>
                                            <h2><?php the_title(); ?></h2>
                                        </div>
                                        <div class="text"><?php the_excerpt(); ?></div>
                                        <div class="link-box">
                                            <a href="<?php echo esc_url(the_permalink()); ?>" class="read-more"><?php echo esc_html__('view detail', 'solustrid-core'); ?>  <span class="arrow fas fa-angle-right"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $i++;
                    }

                    wp_reset_postdata();
                }
                ?>
            </div>
        </section>
        <!--End Features Section Two -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new ProjectsTwo());
