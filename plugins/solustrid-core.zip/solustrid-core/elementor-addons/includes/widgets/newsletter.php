<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class newsletter extends Widget_Base {

    public function get_name() {
        return 'newsletter';
    }

    public function get_title() {
        return esc_html__('Newsletter', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_newsletter', [
            'label' => esc_html__('Content', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Stay Updated With Our Newsletter', 'solustrid-core')
                ]
        );

        $this->add_control(
                'action_link', [
            'label' => __('Form Action Link', 'solustrid-core'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => '#',
                'is_external' => '',
            ],
            'show_external' => true,
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }
        ?>
        <!--Newsleter Section-->
        <section class="newsletter-section wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="row clearfix">
                        <!--Title Column-->
                        <div class="title-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <h2>
                                    <?php
                                    echo wp_kses_post($settings['title']);
                                    ?>
                                </h2>
                            </div>
                        </div>
                        <!--Form Column-->
                        <div class="form-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <!--Subscribe Form-->
                                <div class="subscribe-form">
                                    <form action="<?php echo esc_url($url) ?>"  method="post" class="wpcf7-form" novalidate="novalidate">
                                        <div class="form-group">
                                            <span class="icon far fa-envelope"></span>
                                            <input type="email" name="your-email" value="" placeholder="<?php echo esc_attr__('Email address ...', 'solustrid-core') ?>" required>
                                            <button type="submit" class="theme-btn submit-btn"><?php echo esc_html__('Submit', 'solustrid-core') ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Newsleter Section-->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new newsletter());
?>
