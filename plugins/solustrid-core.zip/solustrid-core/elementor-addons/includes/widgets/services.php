<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Services extends Widget_Base {

    public function get_name() {
        return 'custom_services';
    }

    public function get_title() {
        return esc_html__('Services', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Services', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Services For Industries', 'solustrid-core')
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Heading Content', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit voluptate velit sunt in culpa qui officia deseru mollit anim ipsum id est laborum.'
                ]
        );

        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__(6, 'solustrid-core')
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => 'solustrid_services',
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        ?>

        <!-- Services Section Two -->
        <section class="services-section-two">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="big-icon flaticon-settings-4"></div>
                    <!-- Sec Title -->
                    <div class="sec-title light wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="row clearfix">
                            <div class="pull-left col-xl-4 col-lg-5 col-md-12 col-sm-12">
                                <div class="title">
                                    <?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?>
                                </div>
                                <h2>
                                    <?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?>
                                </h2>
                            </div>
                            <div class="pull-left col-xl-8 col-lg-7 col-md-12 col-sm-12">
                                <div class="text">  
                                    <?php
                                    echo wp_kses_post($settings['content']);
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="three-item-carousel owl-carousel owl-theme">
                        <?php
                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                                $solustrid_pmeta_image = get_post_meta(get_the_ID(), 'framework-home-sect-image', TRUE);
                                $solustrid_image_src = wp_get_attachment_image_src($solustrid_pmeta_image, 'full');
                                ?>
                                <!-- Services Block Two -->
                                <div class="services-block-two">
                                    <div class="inner-box">
                                        <div class="image">
                                            <a href="<?php echo esc_url(the_permalink()); ?>">
                                                <?php if (isset($solustrid_image_src[0]) && !empty($solustrid_image_src[0])) { ?>
                                                    <img src="<?php echo esc_url($solustrid_image_src[0]); ?>" alt="<?php echo esc_attr('Alt'); ?>"/>
                                                    <?php
                                                } else {
                                                    the_post_thumbnail();
                                                }
                                                ?>
                                            </a>
                                        </div>
                                        <div class="lower-content">
                                            <h3><a href="<?php echo esc_url(the_permalink()); ?>"><?php the_title(); ?></a></h3>
                                            <div class="text"><?php echo get_the_excerpt(); ?></div>
                                            <a href="<?php echo esc_url(the_permalink()); ?>" class="read-more"><?php echo esc_html__('Read More', 'solustrid-core'); ?> <span class="arrow flaticon-next"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Services Section Two -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Services());
