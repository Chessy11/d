<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class Brands extends Widget_Base {

    public function get_name() {
        return 'brands';
    }

    public function get_title() {
        return esc_html__('Brands', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'heading_settings', [
            'label' => esc_html__('Content Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We are committed to provide safe <br> industrial solutions to many factories'
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'At Solustrid, Our goal is to generate oriented sales by our staff  members which enables us to meet the clients expectations in <br> timely manner ipsum dolor sit amet consectetur adipisicing elit sed ipsum eiusmod tempor incididunt labore'
                ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Logo Settings', 'solustrid-core')
                ]
        );

        $this->add_control(
                'brand_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
                ['tab_title' => esc_html__('Item', 'solustrid-core')],
                ['tab_title' => esc_html__('Item', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'size',
                    'label' => esc_html__('Select Size', 'solustrid-core'),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'full',
                    'options' => [
                        'full' => esc_html__('Full', 'solustrid-core'),
                        'custom' => esc_html__('Custom', 'solustrid-core')
                    ]
                ],
                [
                    'name' => 'width',
                    'label' => esc_html__('Width', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'size' => 'custom',
                    ],
                ],
                [
                    'name' => 'height',
                    'label' => esc_html__('Height', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'size' => 'custom',
                    ],
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true
                ],
                [
                    'name' => 'extra_class',
                    'label' => esc_html__('Extra Class', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <!-- Factory Section -->
        <section class="factory-section" style="background-image:url(<?php echo esc_url($settings['image']['url']) ?>)">
            <div class="auto-container">
                <!-- Title Box -->
                <div class="title-box">
                    <h2>
                        <?php
                        echo wp_kses_post($settings['title_1']);
                        ?>
                    </h2>
                    <div class="text">
                        <?php
                        echo wp_kses_post($settings['title_2']);
                        ?>
                    </div>
                </div>
                <div class="factories-icons-carousel owl-carousel owl-theme">
                    <?php
                    foreach ($settings['brand_tabs_tab'] as $tab) {
                        $attachment_size = array();
                        $has_custom_size = FALSE;
                        if (!empty($tab['width']) && !empty($tab['height'])) {
                            $has_custom_size = true;
                            $attachment_size[0] = (int) $tab['width'];
                            $attachment_size[1] = (int) $tab['height'];
                        }

                        if (!$has_custom_size) {
                            $attachment_size = 'full';
                        }

                        $url = '#';
                        $target = '';
                        if (!empty($tab['action_link'])) {
                            $link = $tab['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        if (is_array($attachment_size)) {
                            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $tab['width'], 'height' => (int) $tab['height']]];
                            $image_url = Group_Control_Image_Size::get_attachment_image_src($tab['image']['id'], 'image', $instance);
                        } else {
                            if (!empty($tab['image']['id'])) {
                                $image_src = wp_get_attachment_image_src($tab['image']['id'], $attachment_size);
                                $image_url = $image_src[0];
                            } else {
                                $image_url = $tab['image']['url'];
                            }
                        }
                        ?>
                        <div class="factory-icon">
                            <a href="<?php echo esc_url($url); ?>" <?php echo $target; ?>>
                                <img src="<?php echo esc_url($image_url); ?>" alt= "<?php echo esc_html__('Image', 'solustrid-core') ?>"/>
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>
        <!-- End Factory Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Brands());
