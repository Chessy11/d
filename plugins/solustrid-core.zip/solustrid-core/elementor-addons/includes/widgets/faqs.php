<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Faqs extends Widget_Base {

    public function get_name() {
        return 'faqs';
    }

    public function get_title() {
        return esc_html__('Faqs', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'section_style', [
            'label' => __('Faq Style', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1' => __('1', 'solustrid-core'),
                '2' => __('2', 'solustrid-core'),
            ],
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Here you can find some FAQ’s at Solustrid, Our goal is to generate oriented sales by our staff members which enables us to meet the clients expectations in timely manner ipsum dolor sit amet consectetur adipisicing elit sed.'
                ]
        );

        $this->add_control(
                'faq_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Taqs Item', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #4', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #5', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'question',
                    'label' => esc_html__('Question', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Leading industrial solutions with best machinery'
                ],
                [
                    'name' => 'answer',
                    'label' => esc_html__('Answer ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Officia deserunt mollit anim id est laborum ut perspiciatis unde omnis natus error sit voluptatem accusantium dolor mque laudantium totam eaque ipsa quae ab illo inventore veritatis et quasis.'
                ],
                [
                    'name' => 'state',
                    'label' => __('Is Active', 'plugin-domain'),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __('Show', 'solustrid-core'),
                    'label_off' => __('Hide', 'solustrid-core'),
                    'return_value' => 'no'
                ],
                [
                    'name' => 'extra_class',
                    'label' => esc_html__('Extra Class', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <ul class="accordion-box">
            <!--Block-->
            <?php
            foreach ($settings['faq_item'] as $tab) {
                $active = '';
                $button = '';
                $current = '';
                if ($tab['state']) {
                    $active = 'active-block';
                    $button = 'active';
                    $current = 'current';
                }
                ?>
                <li class="accordion block <?php echo esc_attr($active); ?> wow fadeInUp">
                    <div class="acc-btn <?php echo esc_attr($button); ?>"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span></div><?php echo wp_kses_post($tab['question']); ?></div>
                    <div class="acc-content <?php echo esc_attr($current); ?>">
                        <div class="content">
                            <div class="text"><?php echo wp_kses_post($tab['answer']); ?></div>
                        </div>
                    </div>
                </li>
                <?php
            }
            ?>
        </ul>
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Faqs());
?>
