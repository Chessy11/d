<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class newsletter2 extends Widget_Base {

    public function get_name() {
        return 'newsletter2';
    }

    public function get_title() {
        return esc_html__('Newsletter Two', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_newsletter', [
            'label' => esc_html__('Content', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'Stay Updated With Our Newsletter'
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'At Solustrid, Our goal is to generate oriented sales by our staff  members which enables us to meet the clients expectations in timely manner ipsum dolor sit amet consectetur adipisicing elit sed ipsum eiusmod tempor incididunt labore'
                ]
        );

        $this->add_control(
                'action_link', [
            'label' => __('Form Action Link', 'solustrid-core'),
            'type' => Controls_Manager::URL,
            'default' => [
                'url' => '#',
                'is_external' => '',
            ],
            'show_external' => true,
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $url = '#';
        $target = '';
        if (!empty($settings['action_link'])) {
            $link = $settings['action_link'];
            $url = $link['url'];
            $target = $link['is_external'] ? 'target="_blank"' : '';
        }
        ?>

        <!--Newsleter Section Two-->
        <section class="newsletter-section-two">
            <div class="auto-container">
                <!--Title Column-->
                <div class="title-box wow fadeInDown" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="inner-column">
                        <h2> <?php
                            echo wp_kses_post($settings['title_1']);
                            ?></h2>
                        <div class="text"><?php
                            echo wp_kses_post($settings['title_2']);
                            ?></div>
                    </div>
                </div>
                <!--Subscribe Form-->
                <div class="subscribe-form-two wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <form method="post" action="<?php echo esc_url($url) ?>">
                        <div class="form-group">
                            <span class="icon far fa-envelope"></span>
                            <input type="email" name="email" value="" placeholder="<?php echo esc_attr__('Email address ...', 'solustrid-core') ?>" required>
                            <button type="submit" class="theme-btn submit-btn"><?php echo esc_html__('Submit', 'solustrid-core') ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <!--End Newsleter Section-->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new newsletter2());
?>
