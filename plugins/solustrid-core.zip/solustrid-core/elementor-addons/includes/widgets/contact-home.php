<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Contact1 extends Widget_Base {

    public function get_name() {
        return 'home_contact';
    }

    public function get_title() {
        return esc_html__('Home Contact', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_contact', [
            'label' => esc_html__('Contact Info', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We Are Solustrid', 'solustrid-core')
                ]
        );


        $this->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Request a Quote'
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit voluptate aelit sunt.'
                ]
        );

        $this->add_control(
                'cf7_code', [
            'label' => esc_html__('Contact Form 7 Shortcode', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $image_url = $settings['image']['url'];
        ?>
        <!-- Request Quote -->
        <section class="request-quote-section" style="background-image: url(<?php echo esc_url($image_url); ?>);">
            <div class="auto-container">
                <div class="sec-title light">
                    <div class="title"><?php
                        echo wp_kses_post($settings['title_1']);
                        ?></div>
                    <h2><?php
                        echo wp_kses_post($settings['title_2']);
                        ?></h2>
                    <div class="text"><?php
                        echo wp_kses_post($settings['content']);
                        ?></div>
                </div>
                <div class="appointment-form">
                    <?php
                    echo do_shortcode($settings['cf7_code']);
                    ?>
                </div>
            </div>
        </section>
        <!--End Request Quote -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Contact1());
