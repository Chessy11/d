<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Mission extends Widget_Base {

    public function get_name() {
        return 'mission';
    }

    public function get_title() {
        return esc_html__('Mission', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('BG Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'team_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Item', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'image',
                    'label' => __('Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'image_logo',
                    'label' => __('Logo Image', 'solustrid-core'),
                    'type' => Controls_Manager::MEDIA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => [
                        'url' => Utils::get_placeholder_image_src(),
                    ],
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Client Name', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Our Mission'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Incididunt ut labore et dolore magna aliqua veniamtion ullamco laboris nisi ut aliquip ex eac consequat duis derit velit culpa quis labore dolore magna.'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $bg_image = isset($settings['image']['url']) ? $settings['image']['url'] : '#';
        ?>
        <!-- Missin Section -->
        <section class="mission-section" style="background-image: url(<?php echo esc_url($bg_image); ?>);">
            <div class="auto-container">
                <div class="row no-gutters">
                    <?php
                    foreach ($settings['team_item'] as $key => $tab) {
                        if ($key == 0) {
                            ?>
                            <div class="colum col-lg-6 col-md-12 col-sm-12">
                                <div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="content-box" style="background-image: url(<?php echo esc_url($tab['image_logo']['url']); ?>);">
                                        <h4><?php echo esc_html($tab['title']); ?></h4>
                                        <div class="text"><?php echo esc_html($tab['content']); ?></div>
                                    </div>
                                    <div class="image-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <figure class="image"><a href="<?php echo esc_url($tab['image']['url']); ?>" class="lightbox-image">
                                                <img src="<?php echo esc_url($tab['image']['url']); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>">
                                            </a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        <?php } else {
                            ?>
                            <div class="colum right-column col-lg-6 col-md-12 col-sm-12">
                                <div class="inner-column">
                                    <div class="image-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <figure class="image"><a href="<?php echo esc_url($tab['image']['url']); ?>" class="lightbox-image">
                                                <img src="<?php echo esc_url($tab['image']['url']); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>">
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="content-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms" style="background-image: url(<?php echo esc_url($tab['image_logo']['url']); ?>);">
                                        <h4><?php echo esc_html($tab['title']); ?></h4>
                                        <div class="text"><?php echo esc_html($tab['content']); ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </section>
        <!--End Missin Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Mission());
?>