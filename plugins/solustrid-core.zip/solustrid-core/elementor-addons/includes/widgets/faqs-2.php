<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Faqs2 extends Widget_Base {

    public function get_name() {
        return 'faqs2';
    }

    public function get_title() {
        return esc_html__('Faqs 2', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image_logo', [
            'label' => __('Logo Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'title', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'We are Solustrid'
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'We offer Industrial Solutions that are reliable, efficient, safe and sustainable.'
                ]
        );

        $this->add_control(
                'faq_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Taqs Item', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #4', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'question',
                    'label' => esc_html__('Question', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Leading industrial solutions with best machinery'
                ],
                [
                    'name' => 'answer',
                    'label' => esc_html__('Answer ', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Officia deserunt mollit anim id est laborum ut perspiciatis unde omnis natus error sit voluptatem accusantium dolor mque laudantium totam eaque ipsa quae ab illo inventore veritatis et quasis.'
                ],
                [
                    'name' => 'state',
                    'label' => __('Is Active', 'plugin-domain'),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __('Show', 'solustrid-core'),
                    'label_off' => __('Hide', 'solustrid-core'),
                    'return_value' => 'no'
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $image_logo_url = isset($settings['image_logo']['url']) ? $settings['image_logo']['url'] : '#';
        $image_url = isset($settings['image']['url']) ? $settings['image']['url'] : '#';
        ?>
        <!-- FAQ Section -->
        <section class="faq-section">
            <div class="auto-container">
                <div class="row">
                    <!-- Accordion Column -->
                    <div class="accordion-column col-lg-7 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <div class="title-style-one">
                                <div class="icon">
                                    <img src="<?php echo esc_url($image_logo_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"/>
                                </div>
                                <div class="subtitle"><?php
                                    echo wp_kses_post($settings['title']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></h2>
                            </div>
                            <!--Accordian Box-->
                            <ul class="accordion-box">
                                <?php
                                foreach ($settings['faq_item'] as $tab) {
                                    $active = '';
                                    $button = '';
                                    $current = '';
                                    if ($tab['state']) {
                                        $active = 'active-block';
                                        $button = 'active';
                                        $current = 'current';
                                    }
                                    ?>
                                    <!--Block-->
                                    <li class="accordion block <?php echo esc_attr($active); ?> wow fadeInUp">
                                        <div class="acc-btn <?php echo esc_attr($button); ?>"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-right"></span> </div>
                                            <?php echo wp_kses_post($tab['question']); ?>
                                        </div>
                                        <div class="acc-content <?php echo esc_attr($current); ?>">
                                            <div class="content">
                                                <div class="text"><?php echo wp_kses_post($tab['answer']); ?></div>
                                            </div>
                                        </div>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                    <!-- image Column -->
                    <div class="image-column col-lg-5 col-md-12 col-sm-12">
                        <div class="inner-column">
                            <figure class="image wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"/>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End FAQ Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Faqs2());
?>
