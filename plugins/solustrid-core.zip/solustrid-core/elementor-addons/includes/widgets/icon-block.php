<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class iconBlock extends Widget_Base {

    public function get_name() {
        return 'iconBlock';
    }

    public function get_title() {
        return esc_html__('Icon Block', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_settings', [
            'label' => esc_html__('Content', 'solustrid-core')
                ]
        );

        $this->add_control(
                'icon_item', [
            'type' => Controls_Manager::REPEATER,
            'label' => esc_html__('Icon Item', 'solustrid-core'),
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Item #1', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #2', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #3', 'solustrid-core')],
                ['tab_title' => esc_html__('Item #4', 'solustrid-core')]
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'icon',
                    'label' => esc_html__('Icon', 'solustrid-core'),
                    'type' => Controls_Manager::ICON,
                    'include' => [
                        'flaticon-home-2',
                        'flaticon-fan',
                        'flaticon-worker',
                        'flaticon-nuclear-plant'
                    ]
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Well Maintained'
                ],
                [
                    'name' => 'content',
                    'label' => esc_html__('Content', 'solustrid-core'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => 'Incididunt laboret dolore magna exercitation laboris nisis dolor in derit in voluptate velit.'
                ],
                [
                    'name' => 'extra_class',
                    'label' => esc_html__('Extra Class', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        ?>
        <div class="services-featured-outer">
            <div class="row clearfix">
                <?php
                foreach ($settings['icon_item'] as $tab) {
                    $icon = $tab['icon'];
                    $title = $tab['title'];
                    $content = $tab['content'];
                    ?>
                    <!-- Feature Block -->
                    <div class="feature-block col-lg-6 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon-box">
                                <span class="icon <?php echo esc_attr($icon); ?>"></span>
                            </div>
                            <h4><?php echo wp_kses_post($title); ?></h4>
                            <div class="featured-text"><?php echo wp_kses_post($content); ?></div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new iconBlock());
?>