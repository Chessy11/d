<?php

namespace solustrid\Widget;

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class About extends Widget_Base {

    public function get_name() {
        return 'about';
    }

    public function get_title() {
        return esc_html__('About', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'industry_section', [
            'label' => esc_html__('Left Column', 'solustrid-core'),
                ]
        );


        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'We are Solustrid'
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => 'Leading Work That <br>Saves Everyone’s Life'
                ]
        );


        $this->add_control(
                'content', [
            'label' => esc_html__('Content', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => esc_html__('Dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.', 'solustrid-core')
                ]
        );

        $this->add_control(
                'image', [
            'label' => __('Signature Image', 'solustrid-core'),
            'type' => Controls_Manager::MEDIA,
            'dynamic' => [
                'active' => true,
            ],
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
                ]
        );

        $this->add_control(
                'size', [
            'label' => esc_html__('Select Size', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'full' => esc_html__('Full', 'solustrid-core'),
                'custom' => esc_html__('Custom', 'solustrid-core')
            ],
                ]
        );

        $this->add_control(
                'width', [
            'label' => esc_html__('Width', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'height', [
            'label' => esc_html__('Height', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'condition' => [
                'size' => 'custom',
            ],
                ]
        );

        $this->add_control(
                'signature', [
            'label' => esc_html__('Signature', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => 'Daniel Ricardo'
                ]
        );
        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
                'service_right_section', [
            'label' => esc_html__('Right Column', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'countertex_tabs_tab', [
            'type' => Controls_Manager::REPEATER,
            'seperator' => 'before',
            'default' => [
                ['tab_title' => esc_html__('Service 1', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 2', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 3', 'solustrid-core')],
                ['tab_title' => esc_html__('Service 4', 'solustrid-core')],
            ],
            'fields' => [
                [
                    'name' => 'tab_title',
                    'label' => esc_html__('Tab Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Tab Title', 'solustrid-core')
                ],
                [
                    'name' => 'icon_text',
                    'label' => esc_html__('Icon Text', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'flaticon-fan'
                ],
                [
                    'name' => 'title',
                    'label' => esc_html__('Title', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 'Modern Equipments'
                ],
                [
                    'name' => 'action_link',
                    'label' => __('Action Button', 'solustrid-core'),
                    'type' => Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => '',
                    ],
                    'show_external' => true,
                ],
                [
                    'name' => 'delay_time',
                    'label' => esc_html__('Delay Time', 'solustrid-core'),
                    'type' => Controls_Manager::TEXT,
                    'default' => 0
                ]
            ],
            'title_field' => '{{tab_title}}',
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings();
        $attachment_size = array();
        $has_custom_size = FALSE;
        if (!empty($settings['width']) && !empty($settings['height'])) {
            $has_custom_size = true;
            $attachment_size[0] = (int) $settings['width'];
            $attachment_size[1] = (int) $settings['height'];
        }

        if (!$has_custom_size) {
            $attachment_size = 'full';
        }

        if (is_array($attachment_size)) {
            $instance = ['image_size' => 'custom', 'image_custom_dimension' => ['width' => (int) $settings['width'], 'height' => (int) $settings['height']]];
            $image_url = Group_Control_Image_Size::get_attachment_image_src($settings['image']['id'], 'image', $instance);
        } else {
            if (!empty($settings['image']['id'])) {
                $image_src = wp_get_attachment_image_src($settings['image']['id'], $attachment_size);
                $image_url = $image_src[0];
            } else {
                $image_url = $settings['image']['url'];
            }
        }
        ?>
        <!-- About Section -->
        <section class="about-section">
            <div class="outer-container">
                <div class="clearfix">
                    <!-- Left Column -->
                    <div class="left-column clearfix">
                        <div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <!-- Sec Title -->
                            <div class="sec-title">
                                <div class="title"><?php
                                    echo wp_kses_post($settings['title_1']);
                                    ?></div>
                                <h2><?php
                                    echo wp_kses_post($settings['title_2']);
                                    ?></h2>
                            </div>
                            <div class="text"><?php
                                echo wp_kses_post($settings['content']);
                                ?></div>
                            <div class="signature">
                                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr__('Image', 'solustrid-core'); ?>"/>
                            </div>
                            <div class="author-name"><?php
                                echo wp_kses_post($settings['signature']);
                                ?></div>
                        </div>
                    </div>
                    <!-- Right Column -->
                    <div class="right-column clearfix">
                        <div class="inner-column">
                            <div class="row clearfix">
                                <?php
                                foreach ($settings['countertex_tabs_tab'] as $tab) {
                                    $dataDelay = $tab['delay_time'];
                                    $url = '#';
                                    $target = '';
                                    if (!empty($tab['action_link'])) {
                                        $link = $tab['action_link'];
                                        $url = $link['url'];
                                        $target = $link['is_external'] ? 'target="_blank"' : '';
                                    }
                                    ?>
                                    <!--Service Block-->
                                    <div class="services-block-six col-lg-6 col-md-6 col-sm-12">
                                        <div class="inner wow zoomInStable" data-wow-delay="<?php echo esc_attr($dataDelay); ?>ms" data-wow-duration="2000ms">
                                            <div class="icon"><span class="<?php echo esc_attr($tab['icon_text']) ?>"></span></div>
                                            <h3><a href="<?php echo esc_url($url); ?>"><?php
                                                    echo wp_kses_post($tab['title']);
                                                    ?></a></h3>
                                            <a href="<?php echo esc_url($url); ?>" class="over-link"></a>
                                        </div>
                                    </div>
                                <?php }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End About Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new About());
