<?php
if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Widget_Base;

class Projects extends Widget_Base {

    public function get_name() {
        return 'projects';
    }

    public function get_title() {
        return esc_html__('Recent Projects', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-post';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_blogs', [
            'label' => esc_html__('Projects', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'title_1', [
            'label' => esc_html__('Title 1', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('We are Solustrid', 'solustrid-core')
                ]
        );

        $this->add_control(
                'title_2', [
            'label' => esc_html__('Title 2', 'solustrid-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Industrial News', 'solustrid-core')
                ]
        );

        $this->add_control(
                'content', [
            'label' => esc_html__('Heading Content', 'solustrid-core'),
            'type' => Controls_Manager::WYSIWYG,
            'default' => 'Aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit voluptate velit sunt in culpa qui officia deseru mollit anim ipsum id est laborum.'
                ]
        );


        $this->add_control(
                'number', [
            'label' => esc_html__('Number of Post', 'solustrid-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__(3, 'solustrid-core')
                ]
        );

        $this->add_control(
                'order_by', [
            'label' => esc_html__('Order By', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'date',
            'options' => [
                'date' => esc_html__('Date', 'solustrid-core'),
                'ID' => esc_html__('ID', 'solustrid-core'),
                'author' => esc_html__('Author', 'solustrid-core'),
                'title' => esc_html__('Title', 'solustrid-core'),
                'modified' => esc_html__('Modified', 'solustrid-core'),
                'rand' => esc_html__('Random', 'solustrid-core'),
                'comment_count' => esc_html__('Comment count', 'solustrid-core'),
                'menu_order' => esc_html__('Menu order', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'order', [
            'label' => esc_html__('Order', 'solustrid-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'desc',
            'options' => [
                'desc' => esc_html__('DESC', 'solustrid-core'),
                'asc' => esc_html__('ASC', 'solustrid-core')
            ]
                ]
        );

        $this->add_control(
                'extra_class', [
            'label' => esc_html__('Extra Class', 'solustrid-core'),
            'type' => Controls_Manager::TEXT
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        $posts_per_page = $settings['number'];
        $order_by = $settings['order_by'];
        $order = $settings['order'];
        $pg_num = get_query_var('paged') ? get_query_var('paged') : 1;
        $args = array(
            'post_type' => 'solustrid_projects',
            'post_status' => array('publish'),
            'nopaging' => false,
            'paged' => $pg_num,
            'posts_per_page' => $posts_per_page,
            'orderby' => $order_by,
            'order' => $order,
        );

        $query = new WP_Query($args);
        ?>

        <!-- Projects Section -->
        <section class="projects-section">
            <div class="auto-container">
                <!-- Sec Title -->
                <div class="sec-title centered">
                    <div class="title">
                        <?php
                        echo wp_kses_post($settings['title_1']);
                        ?>
                    </div>
                    <h2>
                        <?php
                        echo wp_kses_post($settings['title_2']);
                        ?>
                    </h2>
                </div>
                <!-- Projects Carousel -->
                <div class="projects-carousel">
                    <div class="image-column">
                        <div class="carousel-outer">
                            <div class="image-carousel owl-carousel owl-theme">
                                <!-- Slide Item -->
                                <?php
                                if ($query->have_posts()) {
                                    while ($query->have_posts()) {
                                        $query->the_post();
                                        ?>
                                        <div class="slide-item">
                                            <div class="row clearfix">
                                                <!-- Image Column -->
                                                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                                    <div class="inner-column">
                                                        <div class="image">
                                                            <?php
                                                            the_post_thumbnail();
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Content Column -->
                                                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                                                    <div class="inner-column">
                                                        <?php
                                                        $sub_title = get_post_meta(get_the_ID(), 'framework-service-sub-title', TRUE);
                                                        ?>
                                                        <div class="title"><?php echo esc_html($sub_title); ?></div>
                                                        <h3><?php the_title(); ?></h3>
                                                        <div class="text"><?php the_excerpt(); ?></div>
                                                        <a href="<?php echo esc_url(the_permalink()); ?>" class="read-more"><?php echo esc_html__('view detail', 'solustrid-core'); ?>  <span class="arrow fas fa-angle-right"></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    wp_reset_postdata();
                                }
                                ?>
                            </div>

                            <ul class="thumbs-carousel owl-carousel owl-theme">
                                <?php
                                if ($query->have_posts()) {
                                    while ($query->have_posts()) {
                                        $query->the_post();
                                        $solustrid_pmeta_image = get_post_meta(get_the_ID(), 'framework-project-gallery', TRUE);
                                        if ($solustrid_pmeta_image) {
                                            ?>
                                            <li>
                                                <?php
                                                echo wp_get_attachment_image($solustrid_pmeta_image, 'full');
                                                ?>
                                            </li>
                                        <?php } else {
                                            ?>
                                            <li>
                                                <?php
                                                the_post_thumbnail();
                                                ?>
                                            </li>
                                        <?php }
                                        ?>
                                        <?php
                                    }
                                    wp_reset_postdata();
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Projects Section -->
        <?php
    }

    protected function content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new Projects());
