<?php

use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

class featuredBlock extends \Elementor\Widget_Base {

    public function get_name() {
        return 'featureblock';
    }

    public function get_title() {
        return esc_html__('Featured Block', 'solustrid-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['solustrid'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'content_section', [
            'label' => __('Featured Content', 'solustrid-core'),
                ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'icon', [
            'label' => __('Icon', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::ICON,
            'default' => 'icon flaticon-market',
            'include' => [
                'icon flaticon-market',
                'icon flaticon-gear',
                'icon flaticon-branch'
            ],
                ]
        );

        $repeater->add_control(
                'action_link', [
            'label' => __('URL', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'solustrid-core'),
            'show_external' => true,
            'default' => [
                'url' => '#',
                'is_external' => true,
                'nofollow' => true,
            ],
                ]
        );

        $repeater->add_control(
                'url_text', [
            'label' => __('URL Text', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'rows' => 5,
            'default' => __('We provide accurate responses to client’s requirements', 'solustrid-core'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $repeater->add_control(
                'content', [
            'label' => __('Content', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::WYSIWYG,
            'rows' => 5,
            'default' => __('Auis nostrud exercitation sed minim ullamc laboris sed nisit aliquip volpta exea sed consequat dui ipsum duis tempor incididunt ut labore.', 'solustrid-core'),
            'placeholder' => __('Type your description here', 'solustrid-core'),
                ]
        );

        $this->add_control(
                'items', [
            'label' => __('Repeater List', 'solustrid-core'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'list_title' => __('Title #1', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ],
                [
                    'list_title' => __('Title #2', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ],
                [
                    'list_title' => __('Title #3', 'solustrid-core'),
                    'list_content' => __('Item content. Click the edit button to change this text.', 'solustrid-core'),
                ]
            ],
                ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="features-section">
            <div class="outer-container">
                <div class="row no-gutters">
                    <!-- Feature Block Six -->
                    <?php
                    foreach ($settings['items'] as $item) {
                        $url = '#';
                        $target = '';
                        if (!empty($item['action_link'])) {
                            $link = $item['action_link'];
                            $url = $link['url'];
                            $target = $link['is_external'] ? 'target="_blank"' : '';
                        }
                        ?>
                        <div class="feature-block-six col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <div class="icon-box"><span class="<?php echo $item['icon']; ?>"></span></div>  
                                <h5><a href="<?php echo esc_url($url); ?>"><?php echo $item['url_text']; ?></a></h5>
                                <div class="text"><?php echo $item['content']; ?></div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </section>
        <?php
    }

    protected function _content_template() {
        
    }

}

Plugin::instance()->widgets_manager->register_widget_type(new featuredBlock());
