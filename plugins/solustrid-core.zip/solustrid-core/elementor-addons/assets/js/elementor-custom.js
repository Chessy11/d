(function ($) {

    "use strict";

    // carousel
    var singleItemCarousel = function ($scope, $) {
        var tt = $scope.find('.single-item-carousel').each(function () {
            $('.single-item-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: true,
                singleItem: true,
                smartSpeed: 700,
                autoHeight: false,
                autoplay: true,
                autoplayTimeout: 10000,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1024: {
                        items: 1
                    },
                }
            });
        });
    }

    // Three Item Carousel
    var featuredProject = function ($scope, $) {
        var tt = $scope.find('.featured-project-carousel').each(function () {
            $('.featured-project-carousel').owlCarousel({
                animateOut: 'slideOutDown',
                animateIn: 'fadeInDown',
                loop: true,
                margin: 30,
                nav: true,
                singleItem: true,
                smartSpeed: 700,
                autoHeight: true,
                autoplay: true,
                autoplayTimeout: 10000,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1024: {
                        items: 1
                    },
                }
            });
        });
    }

    // Three Item Carousel
    var threeItemCarousel = function ($scope, $) {
        var tt = $scope.find('.three-item-carousel').each(function () {
            $('.three-item-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: true,
                smartSpeed: 500,
                autoplay: true,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    778: {
                        items: 2
                    },
                    1024: {
                        items: 3
                    },
                    1280: {
                        items: 3
                    }
                }
            });
        });
    }

    // Sponsors Carousel
    if ($('.sponsors-carousel').length) {
        $('.sponsors-carousel').owlCarousel({
            loop: true,
            margin: 30,
            nav: true,
            smartSpeed: 500,
            autoplay: true,
            navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                800: {
                    items: 3
                },
                1024: {
                    items: 4
                },
                1200: {
                    items: 5
                }

            }
        });
    }

    // carousel
    var factoriesIconsCarousel = function ($scope, $) {
        var tt = $scope.find('.factories-icons-carousel').each(function () {

            $('.factories-icons-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: true,
                smartSpeed: 500,
                autoplay: true,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    800: {
                        items: 3
                    },
                    1024: {
                        items: 4
                    },
                    1200: {
                        items: 5
                    }

                }
            });


        });
    }

    // News Carousel
    var newsCarousel = function ($scope, $) {
        var tt = $scope.find('.news-carousel').each(function () {
            $('.news-carousel').owlCarousel({
                loop: true,
                margin: 0,
                nav: true,
                smartSpeed: 700,
                autoHeight: true,
                autoplay: true,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    768: {
                        items: 2
                    },
                    800: {
                        items: 2
                    },
                    1024: {
                        items: 3
                    },
                    1200: {
                        items: 3
                    },
                    1400: {
                        items: 4
                    }

                }
            });

        });
    }

    // Testimonials Carousel
    var testimonials2Carousel = function ($scope, $) {
        var tt = $scope.find('.testimonial-carousel').each(function () {
            $('.testimonial-carousel').owlCarousel({
                loop: true,
                margin: 30,
                nav: true,
                smartSpeed: 500,
                autoplay: true,
                navText: ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
                responsive: {
                    0: {
                        items: 1
                    },
                    764: {
                        items: 1
                    },
                    800: {
                        items: 2
                    },
                    1024: {
                        items: 2
                    },
                    1200: {
                        items: 3
                    }

                }
            });


        });
    }

    // carousel
    var projects = function ($scope, $) {
        var tt = $scope.find('.projects-carousel .image-carousel').each(function () {
            var $sync1 = $(".projects-carousel .image-carousel"),
                    $sync2 = $(".projects-carousel .thumbs-carousel"),
                    flag = false,
                    duration = 500;

            $sync1
                    .owlCarousel({
                        animateOut: 'fadeOut',
                        animateIn: 'fadeIn',
                        loop: true,
                        items: 1,
                        margin: 30,
                        nav: false,
                        navText: ['<span class="icon fa fa-angle-left"></span>', '<span class="icon fa fa-angle-right"></span>'],
                        dots: false,
                        autoplay: true,
                        autoplayTimeout: 5000
                    })
                    .on('changed.owl.carousel', function (e) {
                        if (!flag) {
                            flag = false;
                            $sync2.trigger('to.owl.carousel', [e.item.index, duration, true]);
                            flag = false;
                        }
                    });

            $sync2
                    .owlCarousel({
                        loop: true,
                        margin: 15,
                        items: 1,
                        nav: true,
                        navText: ['<span class="icon fa fa-angle-left"></span>', '<span class="icon fa fa-angle-right"></span>'],
                        dots: false,
                        center: false,
                        autoplay: true,
                        autoplayTimeout: 5000,
                        responsive: {
                            0: {
                                items: 2,
                                autoWidth: false
                            },
                            400: {
                                items: 2,
                                autoWidth: false
                            },
                            600: {
                                items: 4,
                                autoWidth: false
                            },
                            900: {
                                items: 5,
                                autoWidth: false
                            },
                            1000: {
                                items: 5,
                                autoWidth: false
                            }
                        },
                    })

                    .on('click', '.owl-item', function () {
                        $sync1.trigger('to.owl.carousel', [$(this).index(), duration, true]);
                    })
                    .on('changed.owl.carousel', function (e) {
                        if (!flag) {
                            flag = true;
                            $sync1.trigger('to.owl.carousel', [e.item.index, duration, true]);
                            flag = false;
                        }
                    });

        });
    }

    //Contact Form Validation
    if ($('#contact-form').length) {
        $('#contact-form').validate({
            rules: {
                username: {
                    required: true
                },
                lastname: {
                    required: true
                },
                email: {
                    required: true,
                    email: true
                },
                phone: {
                    required: true
                },
                company: {
                    required: true
                },
                subject: {
                    required: true
                },
                message: {
                    required: true
                }
            }
        });
    }
    //Elementor JS Hooks
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/custom_services.default', threeItemCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/testimonials_carousel.default', singleItemCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/brands.default', factoriesIconsCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/brands2.default', factoriesIconsCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/projects.default', projects);
        elementorFrontend.hooks.addAction('frontend/element_ready/featuredProjects.default', featuredProject);
        elementorFrontend.hooks.addAction('frontend/element_ready/testimonials2.default', testimonials2Carousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/blogstwo.default', newsCarousel);
    });
})(window.jQuery);