<?php

// Adds widget: Title
class solustrid_Contact_Widget extends WP_Widget {

    function __construct() {
        parent::__construct(
                'title_widget', esc_html__('Contact Info', 'solustrid-core'), array('description' => esc_html__('Contact Details', 'solustrid-core'),) // Args
        );
    }

    private $widget_fields = array(
        array(
            'label' => 'Title',
            'id' => 'title_text',
            'default' => 'Contact Details',
            'type' => 'text',
        ),
        array(
            'label' => 'Heading',
            'id' => 'heading',
            'default' => 'Get in touch with us for any questions about our industries or projects.',
            'type' => 'text',
        ),
        array(
            'label' => 'Location Title',
            'id' => 'location_title_text',
            'default' => 'Head Office',
            'type' => 'text',
        ),
        array(
            'label' => 'Location',
            'id' => 'location',
            'default' => '73 Ringer House Lane, Dynatis Newyork 33022, USA',
            'type' => 'text',
        ),
        array(
            'label' => 'Address Title',
            'id' => 'address_title_text',
            'default' => 'Factory Address',
            'type' => 'text',
        ),
        array(
            'label' => 'Address',
            'id' => 'address',
            'default' => 'Suite # 140 Belfast Ave, Trendys Florida 33022, USA',
            'type' => 'text',
        ),
        array(
            'label' => 'Email Title',
            'id' => 'email_title_text',
            'default' => 'Email us',
            'type' => 'text',
        ),
        array(
            'label' => 'Email',
            'id' => 'email',
            'default' => 'solustrid@example.com',
            'type' => 'text',
        ),
        array(
            'label' => 'Phone Title',
            'id' => 'phone_title_text',
            'default' => 'Call Support',
            'type' => 'text',
        ),
        array(
            'label' => 'Phone',
            'id' => 'phone',
            'default' => '+(345) 206 7849',
            'type' => 'text',
        ),
        array(
            'label' => 'Social Block',
            'id' => 'social',
            'default' => '<ul class="social-links"><li><a href="#"><span class="fab fa-facebook-f"></span></a></li> 							<li><a href="#"><span class="fab fa-google-plus-g"></span></a></li> 							<li><a href="#"><span class="fab fa-twitter"></span></a></li> 							<li><a href="#"><span class="fab fa-linkedin-in"></span></a></li> 							<li><a href="#"><span class="fab fa-youtube"></span></a></li> 						</ul>',
            'type' => 'textarea',
        ),
    );

    public function widget($args, $instance) {
        echo $args['before_widget'];
        // Output generated fields
        echo '<p>' . $instance['title_text'] . '</p>';
        echo '<p>' . $instance['heading'] . '</p>';
        echo '<p>' . $instance['location_title_text'] . '</p>';
        echo '<p>' . $instance['location'] . '</p>';
        echo '<p>' . $instance['address_title_text'] . '</p>';
        echo '<p>' . $instance['address'] . '</p>';
        echo '<p>' . $instance['email_title_text'] . '</p>';
        echo '<p>' . $instance['email'] . '</p>';
        echo '<p>' . $instance['phone_title_text'] . '</p>';
        echo '<p>' . $instance['phone'] . '</p>';
        echo '<p>' . $instance['social'] . '</p>';

        echo $args['after_widget'];
    }

    public function field_generator($instance) {
        $output = '';
        foreach ($this->widget_fields as $widget_field) {
            $default = '';
            if (isset($widget_field['default'])) {
                $default = $widget_field['default'];
            }
            $widget_value = !empty($instance[$widget_field['id']]) ? $instance[$widget_field['id']] : esc_html__($default, 'solustrid-core');
            switch ($widget_field['type']) {
                case 'textarea':
                    $output .= '<p>';
                    $output .= '<label for="' . esc_attr($this->get_field_id($widget_field['id'])) . '">' . esc_attr($widget_field['label'], 'solustrid-core') . ':</label> ';
                    $output .= '<textarea class="widefat" id="' . esc_attr($this->get_field_id($widget_field['id'])) . '" name="' . esc_attr($this->get_field_name($widget_field['id'])) . '" rows="6" cols="6" value="' . esc_attr($widget_value) . '">' . $widget_value . '</textarea>';
                    $output .= '</p>';
                    break;
                default:
                    $output .= '<p>';
                    $output .= '<label for="' . esc_attr($this->get_field_id($widget_field['id'])) . '">' . esc_attr($widget_field['label'], 'solustrid-core') . ':</label> ';
                    $output .= '<input class="widefat" id="' . esc_attr($this->get_field_id($widget_field['id'])) . '" name="' . esc_attr($this->get_field_name($widget_field['id'])) . '" type="' . $widget_field['type'] . '" value="' . esc_attr($widget_value) . '">';
                    $output .= '</p>';
            }
        }
        echo $output;
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : esc_html__('', 'solustrid-core');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('Title:', 'solustrid-core'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
        $this->field_generator($instance);
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title']) ) ? strip_tags($new_instance['title']) : '';
        foreach ($this->widget_fields as $widget_field) {
            switch ($widget_field['type']) {
                default:
                    $instance[$widget_field['id']] = (!empty($new_instance[$widget_field['id']]) ) ? strip_tags($new_instance[$widget_field['id']]) : '';
            }
        }
        return $instance;
    }

}

function register_solusContact_widget() {
    register_widget('solustrid_Contact_Widget');
}

add_action('widgets_init', 'register_solusContact_widget');
