<?php
add_action('widgets_init', 'solustrid_sidebar_recent_post');

function solustrid_sidebar_recent_post() {
    register_widget('solustridRecentPost');
}

class solustridRecentPost extends WP_Widget {

    private $defaults = array();

    function __construct() {
        $this->defaults = array(
            'title' => esc_html__('Sidebar Recent Post', 'solustrid-core'),
            'number' => 4,
        );
        parent::__construct('widget_latest_posts_tab_1 ', esc_html__('Solustrid Sidebar Recent Posts', 'solustrid-core'));
    }

    function update($new_instance, $old_instance) {
        $defaults = $this->defaults;
        $instance = $old_instance;
        $instance['title'] = esc_attr($new_instance['title']);
        $instance['number'] = intval($new_instance['number']);
        return $instance;
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, $this->defaults);
        $title = isset($instance['title']) ? esc_attr($instance['title']) : '';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'solustrid-core'); ?></label>
            <input type="text" name="<?php echo esc_attr($this->get_field_name('title')); ?>"  value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" />
        </p>
        <p>
            <label for="<?php print esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts:', 'solustrid-core'); ?>
                <input class="widefat" id="<?php print esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo isset($instance['number']) ? esc_attr($instance['number']) : ''; ?>" />
            </label>
        </p>
        <?php
    }

    function widget($args, $instance) {
        $instance = wp_parse_args((array) $instance, $this->defaults);
        extract($args);
        $number = isset($instance['number']) ? $instance['number'] : 2;
        $title = $instance['title'];
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
      
        ?>
        <div class="sidebar-widget popular-posts">
            <div class="sidebar-title"><h5><?php echo wp_kses_post($title); ?></h5></div>
            <div class="widget-content">
                <?php
                $query_args = array(
                    'posts_per_page' => $number,
                    'no_found_rows' => true,
                    'post_status' => 'publish',
                    'ignore_sticky_posts' => true
                );
                $query = new WP_Query($query_args);
                if ($query->have_posts()) {
                    while ($query->have_posts()) :
                        $query->the_post();
                        ?>
                        <article class="post">
                            <div class="post-inner">
                                <figure class="post-thumb"><a href="<?php esc_url(the_permalink()); ?>"><?php echo the_post_thumbnail('solustrid-blog-sidebar'); ?></a></figure>
                                <div class="text"><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></div>
                                <div class="post-info"><?php echo get_the_date(); ?></div>
                            </div>
                        </article>
                        <?php
                    endwhile;
                    wp_reset_query();
                    echo '</div></div>';
                }
            }

        }
        ?>