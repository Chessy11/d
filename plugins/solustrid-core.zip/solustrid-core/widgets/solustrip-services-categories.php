<?php
add_action('widgets_init', 'solustrid_services_categories');

function solustrid_services_categories() {
    register_widget('solustridServiceCategories');
}

class solustridServiceCategories extends WP_Widget {

    private $defaults = array();

    function __construct() {
        $this->defaults = array(
            'title' => esc_html__('Solustrid Services Category', 'solustrid-core'),
            'number' => 4,
        );
        parent::__construct('widget_services_category', esc_html__('Solustrid Services Category', 'solustrid-core'));
    }

    function update($new_instance, $old_instance) {
        $defaults = $this->defaults;
        $instance = $old_instance;
        $instance['title'] = esc_attr($new_instance['title']);
        return $instance;
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, $this->defaults);
        $title = isset($instance['title']) ? esc_attr($instance['title']) : '';
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'solustrid-core'); ?></label>
            <input type="text" name="<?php echo esc_attr($this->get_field_name('title')); ?>"  value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" />
        </p>
        <?php
    }

    function widget($args, $instance) {
        $instance = wp_parse_args((array) $instance, $this->defaults);
        extract($args);
        $title = $instance['title'];
        ?>
        <div class="sidebar-widget categories-two">
            <div class="widget-content">
                <!-- Services Category -->
                <ul class="services-categories">
                    <?php
                    $args = array(
                        'post_type' => 'solustrid_services',
                        'post_status' => 'publish',
                        'posts_per_page' => -1
                    );
                    $posts = new WP_Query($args);
                    if ($posts->have_posts()) {
                        $i = 1;
                        while ($posts->have_posts()) {
                            $posts->the_post();
                            if ($i == 1) {
                                $active = 'active';
                            } else {
                                $active = '';
                            }
                            ?>
                            <li><a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a></li>
                            <?php
                            $i++;
                        }
                        wp_reset_query();
                    }
                    ?>
                </ul>
            </div>
        </div>
        <?php
    }

}
?>