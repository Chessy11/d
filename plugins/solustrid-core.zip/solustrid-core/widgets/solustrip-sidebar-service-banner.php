<?php

class solustridSidebarBanner extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        parent::__construct(
                'solustrip_sidebar_banner', // Base ID
                __('Solustrid Sidebar Banner', 'solustrid-core'), // Name
                array('description' => __('Solustrid Sidebar Banner', 'solustrid-core'),) // Args
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance) {
        $image = '#';
        if ($instance['image']) {
            $image_src = wp_get_attachment_image_src($instance['image'], "full");
            $image = $image_src[0];
        }
        $url = !empty($instance['url']) ? $instance['url'] : '#';
        ?>
        <!-- Services Widget -->
        <div class="sidebar-widget services-widget">
            <div class="widget-content" style="background-image:url(<?php echo esc_url($image); ?>);">
                <div class="icon flaticon-settings-4"></div>
                <h3><?php echo $instance['title'] ?></h3>
                <div class="text"><?php echo $instance['description']; ?></div>
                <a href="#" class="theme-btn btn-style-two"><?php echo esc_html('get in touch', 'solustrid-core') ?></a>
            </div>
        </div>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['description'] = sanitize_text_field($new_instance['description']);
        $instance['image'] = sanitize_text_field($new_instance['image']);
        $instance['url'] = sanitize_text_field($new_instance['url']);
        return $instance;
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Optimising Perfomance with Special Services', 'solustrid-core');
        $description = isset($instance['description']) ? $instance['description'] : __('Discover how we\'re improving <br> quality of Industries', 'solustrid-core');
        if (!isset($instance['image'])) {
            $instance['image'] = "";
        }
        if (!isset($instance['url'])) {
            $instance['url'] = "";
        }
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title', 'solustrid'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('description')); ?>"><?php _e('Description', 'solustrid'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('description')); ?>" name="<?php echo esc_attr($this->get_field_name('description')); ?>"><?php echo wp_kses_post($description); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Image', 'solustrid-core'); ?></label>
        </p>

        <p class="imgpreview"></p>
        <input class="imgph" type="hidden" id="<?php echo esc_attr($this->get_field_id('image')); ?>" name="<?php echo esc_attr($this->get_field_name('image')); ?>"  value="<?php echo esc_attr($instance['image']); ?>"  />
        <input type="button" class="button btn-primary widgetuploader" value="<?php _e('Add Image', 'solustrid-core'); ?>" />
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('url')); ?>"><?php _e('Target URL', 'solustrid-core'); ?></label>
            <br/>
            <input class="widefat" type="url" id="<?php echo esc_attr($this->get_field_id('url')); ?>" name="<?php echo esc_attr($this->get_field_name('url')); ?>" value="<?php echo esc_attr($instance['url']); ?>" />
        </p>
        <?php
    }

}

function solustrid_widget_register() {
    register_widget('solustridSidebarBanner');
}

add_action('widgets_init', 'solustrid_widget_register');
