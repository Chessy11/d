<?php

// Register Custom Post Type
function solustrid_services_post_type() {

    $labels = array(
        'name' => _x('Services', 'Post Type General Name', 'solustrid-core'),
        'singular_name' => _x('Service', 'Post Type Singular Name', 'solustrid-core'),
        'menu_name' => __('Services', 'solustrid-core'),
        'name_admin_bar' => __('Service', 'solustrid-core'),
        'archives' => __('Item Archives', 'solustrid-core'),
        'parent_item_colon' => __('Parent Item:', 'solustrid-core'),
        'all_items' => __('All Services', 'solustrid-core'),
        'add_new_item' => __('Add New Service', 'solustrid-core'),
        'add_new' => __('Add New Service', 'solustrid-core'),
        'new_item' => __('New Service Item', 'solustrid-core'),
        'edit_item' => __('Edit Service Item', 'solustrid-core'),
        'update_item' => __('Update Service Item', 'solustrid-core'),
        'view_item' => __('View Service Item', 'solustrid-core'),
        'search_items' => __('Search Item', 'solustrid-core'),
        'not_found' => __('Not found', 'solustrid-core'),
        'not_found_in_trash' => __('Not found in Trash', 'solustrid-core'),
        'featured_image' => __('Featured Image', 'solustrid-core'),
        'set_featured_image' => __('Set featured image', 'solustrid-core'),
        'remove_featured_image' => __('Remove featured image', 'solustrid-core'),
        'use_featured_image' => __('Use as featured image', 'solustrid-core'),
        'insert_into_item' => __('Insert into item', 'solustrid-core'),
        'uploaded_to_this_item' => __('Uploaded to this item', 'solustrid-core'),
        'items_list' => __('Items list', 'solustrid-core'),
        'items_list_navigation' => __('Items list navigation', 'solustrid-core'),
        'filter_items_list' => __('Filter items list', 'solustrid-core'),
    );

    $args = array(
        'labels' => $labels,
        'description' => __('Description.', 'solustrid-core'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'services'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'editor', 'thumbnail')
    );

    register_post_type('solustrid_services', $args);
}

add_action('init', 'solustrid_services_post_type', 0);
