<?php

add_filter('rwmb_meta_boxes', 'solustrid_register_framework_post_meta_box');

/**
 * Register meta boxes
 *
 * Remember to change "your_prefix" to actual prefix in your project
 *
 * @return void
 */
function solustrid_register_framework_post_meta_box($meta_boxes) {
    global $wp_registered_sidebars;

    /**
     * prefix of meta keys (optional)
     * Use underscore (_) at the beginning to make keys hidden
     * Alt.: You also can make prefix empty to disable it
     */
    // Better has an underscore as last sign
    $prefix = 'framework';

    $sidebars = array();

    foreach ($wp_registered_sidebars as $key => $value) {
        $sidebars[$key] = $value['name'];
    }

    $opacities = array();

    for ($o = 0.0, $n = 0; $o <= 1.0; $o += 0.1, $n++) {
        $opacities[$n] = $o;
    }


    $meta_boxes[] = array(
        'id' => 'framework-meta-box-standart-format',
        'title' => esc_html__('Post Format Data', 'solustrid'),
        'fields' => array(
            array(
                'name' => esc_html__('Upload Image', 'solustrid'),
                'id' => "{$prefix}-meta-image",
                'type' => 'image_advanced',
                'max_file_uploads' => 1,
            )
    ));

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-post-format-video',
        'title' => esc_html__('Post Format Data', 'solustrid'),
        'pages' => array(
            'post',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Video Markup', 'solustrid'),
                'desc' => esc_html__('Put embed src of video. i.e. youtube, vimeo', 'solustrid'),
                'id' => "{$prefix}-video-markup",
                'type' => 'textarea',
                'cols' => 20,
                'rows' => 3,
            ),
    ));

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-post-format-audio',
        'title' => esc_html__('Post Format Data', 'solustrid'),
        'pages' => array(
            'post',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Audio Markup', 'solustrid'),
                'desc' => esc_html__('Put embed src of video. i.e. youtube, vimeo', 'solustrid'),
                'id' => "{$prefix}-audio-markup",
                'type' => 'textarea',
                'cols' => 20,
                'rows' => 3,
            ),
    ));


    $meta_boxes[] = array(
        'id' => 'framework-meta-box-post-format-link',
        'title' => esc_html__('Post Format Data', 'solustrid'),
        'pages' => array(
            'post',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Link', 'solustrid'),
                'desc' => esc_html__('Works with link post format.', 'solustrid'),
                'id' => "{$prefix}-link",
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Link title', 'solustrid'),
                'desc' => esc_html__('Works with link post format.', 'solustrid'),
                'id' => "{$prefix}-link-title",
                'type' => 'text',
            ),
    ));

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-post-format-gallery',
        'title' => esc_html__('Post Format Data', 'solustrid'),
        'pages' => array(
            'post',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Upload Gallery Images', 'solustrid'),
                'id' => "{$prefix}-gallery",
                'desc' => '',
                'type' => 'image_advanced',
                'max_file_uploads' => 24,
            ),
    ));

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-gallery',
        'title' => esc_html__('Manage Gallery Meta Fields', 'solustrid'),
        'pages' => array(
            'gallery',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Gallery Url', 'solustrid'),
                'desc' => esc_html__('Enter Your Gallary Details Url.', 'solustrid'),
                'id' => "{$prefix}-gallery-url",
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Upload Gallery Images', 'solustrid'),
                'id' => "{$prefix}-gallery",
                'desc' => '',
                'type' => 'image',
                'max_file_uploads' => 1,
            ),
    ));


    $posts_page = get_option('page_for_posts');

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-custom-post',
        'title' => esc_html__('Custom Post Data', 'solustrid'),
        'pages' => array(
            'solustrid_services',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'id' => "{$prefix}_show_breadcrumb",
                'name' => esc_html__('Show Breadcrumb', 'solustrid'),
                'desc' => '',
                'type' => 'radio',
                'std' => "on",
                'options' => array('on' => 'Yes', 'off' => 'No'),
            ),
            array(
                'name' => esc_html__('Header Image', 'solustrid'),
                'id' => "framework_header_image",
                'desc' => '',
                'type' => 'image',
                'max_file_uploads' => 1,
            ),
            array(
                'name' => esc_html__('Services Sub Title', 'solustrid'),
                'desc' => esc_html__('Services Sub Title', 'solustrid'),
                'id' => "{$prefix}-service-sub-title",
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Section Image', 'solustrid'),
                'id' => "{$prefix}-home-sect-image",
                'desc' => '',
                'type' => 'image',
                'max_file_uploads' => 1,
            ),
    ));

    $meta_boxes[] = array(
        'id' => 'framework-meta-box-custom-post',
        'title' => esc_html__('Custom Post Data', 'solustrid'),
        'pages' => array(
            'solustrid_projects',
        ),
        'context' => 'normal',
        'priority' => 'high',
        'tab_style' => 'left',
        'fields' => array(
            array(
                'name' => esc_html__('Project Sub Title', 'solustrid'),
                'desc' => esc_html__('Project Sub Title', 'solustrid'),
                'id' => "{$prefix}-project-sub-title",
                'type' => 'text',
            ),
            array(
                'name' => esc_html__('Upload Gallery Images', 'solustrid'),
                'id' => "{$prefix}-project-gallery",
                'type' => 'image',
                'max_file_uploads' => 1,
            )
    ));

    if (!isset($_GET['post']) || intval($_GET['post']) != $posts_page) {
        $meta_boxes[] = array(
            'id' => $prefix . '_page_meta_box',
            'title' => esc_html__('Page Design Settings', 'solustrid'),
            'pages' => array(
                'page',
            ),
            'context' => 'normal',
            'priority' => 'core',
            'fields' => array(
                array(
                    'id' => "{$prefix}_show_page_title",
                    'name' => esc_html__('Show Page Titlebar', 'solustrid'),
                    'desc' => '',
                    'type' => 'radio',
                    'std' => "on",
                    'options' => array('on' => 'Yes', 'off' => 'No'),
                ),
                array(
                    'id' => "{$prefix}_show_breadcrumb",
                    'name' => esc_html__('Show Breadcrumb', 'solustrid'),
                    'desc' => '',
                    'type' => 'radio',
                    'std' => "on",
                    'options' => array('on' => 'Yes', 'off' => 'No'),
                ),
                array(
                    'name' => esc_html__('Header Image', 'solustrid'),
                    'id' => "framework_header_image",
                    'desc' => '',
                    'type' => 'image',
                    'max_file_uploads' => 1,
                )
            )
        );
    }
    return $meta_boxes;
}
